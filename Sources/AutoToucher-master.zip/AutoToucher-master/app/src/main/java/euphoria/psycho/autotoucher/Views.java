package euphoria.psycho.autotoucher;

import android.app.Activity;
import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build.VERSION;
import android.os.Build.VERSION_CODES;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.Toast;

public class Views {
    public static View floatingWindow(WindowManager windowManager, int resId, Context context) {
        if (windowManager == null)
            windowManager = (WindowManager)
                    context.getApplicationContext().getSystemService(Context.WINDOW_SERVICE);

        View view = LayoutInflater.from(context).inflate(resId, null);

        WindowManager.LayoutParams layoutParams = newLayoutParams();

        windowManager.addView(view, layoutParams);
        return view;
    }

    public static void movable(View view) {
        new Movable(view);
    }

    public static LayoutParams newLayoutParams() {
        LayoutParams params = new LayoutParams();
        // 对齐方式
         params.gravity = Gravity.TOP;
        // 浮窗层级
        if (VERSION.SDK_INT >= VERSION_CODES.O) {
            params.type = LayoutParams.TYPE_APPLICATION_OVERLAY;//WindowManager.LayoutParams.TYPE_PHONE;
        } else {
            params.type = LayoutParams.TYPE_PHONE;

        }
        // 背景透明
        params.format = PixelFormat.TRANSLUCENT;
        params.width = LayoutParams.WRAP_CONTENT;
        params.height = LayoutParams.WRAP_CONTENT;

        /*// 全屏显示
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        params.height = WindowManager.LayoutParams.MATCH_PARENT;*/

        // 让window不能获得焦点，这样用户快就不能向该window发送按键事件及按钮事件
        //LayoutParams.FLAG_NOT_FOCUSABLE ;
        params.flags = LayoutParams.FLAG_NOT_TOUCH_MODAL;
        // 让window占满整个手机屏幕，不留任何边界（border）
//        params.flags |= LayoutParams.FLAG_LAYOUT_IN_SCREEN
//                | LayoutParams.FLAG_LAYOUT_INSET_DECOR;
        // window大小不再不受手机屏幕大小限制，即window可能超出屏幕之外，这时部分内容在屏幕之外
        //params.flags |= WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        return params;
    }

    private static class Movable implements OnTouchListener {
        View mView;
        float mDx, mDy;

        public Movable(View view) {
            mView = view;
            mView.setOnTouchListener(this);
        }

        @Override
        public boolean onTouch(View view, MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    mDx = view.getX() - event.getRawX();
                    mDy = view.getY() - event.getRawY();
                    break;
                case MotionEvent.ACTION_MOVE:
                    view.animate()
                            .x(event.getRawX() + mDx)
                            .y(event.getRawY() + mDy)
                            .setDuration(0)
                            .start();
                    break;
                default:
                    return false;
            }
            return true;
        }
    }
}
