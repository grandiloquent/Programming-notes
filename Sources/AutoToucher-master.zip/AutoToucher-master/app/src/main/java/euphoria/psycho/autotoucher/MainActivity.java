package euphoria.psycho.autotoucher;

import android.Manifest;
import android.Manifest.permission;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.os.Build.VERSION;
import android.os.Build.VERSION_CODES;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.Toast;

public class MainActivity extends Activities {

    private static final int REQUEST_CODE_ACCESSIBILITY_SERVICE = 1;
    private static final int REQUEST_CODE_OVERLAY_PERMISSION = 2;
    private static final String TAG = "TAG/" + MainActivity.class.getSimpleName();

    @Override
    void initialize() {
        // checkAccessibilityService(this, REQUEST_CODE_ACCESSIBILITY_SERVICE);
//        if (checkSelfPermission(permission.SYSTEM_ALERT_WINDOW) != PackageManager.PERMISSION_GRANTED)
//            requestOverlayPermission(this, REQUEST_CODE_OVERLAY_PERMISSION);
        requestOverlayPermission(this, REQUEST_CODE_OVERLAY_PERMISSION);
        setContentView(R.layout.activity_main);
        if (Accessibilities.isAccessibilitySettingsOn(this, CustomAccessibilityService.class)) {
            startService(new Intent(this, CustomAccessibilityService.class));
        }
        //Views.floatingWindow(this);

        findViewById(R.id.ok).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(), "OK", Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    String[] needPermissions() {
        return new String[]{
        };
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {


        Log.e(TAG, "Debug: onActivityResult, " + requestCode);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:

                Intent settings = new Intent(this, SettingsActivity.class);
                startActivity(settings);
                return true;
            case R.id.action_accessibility:
                startService(new Intent(this, CustomAccessibilityService.class));
                return true;
            case R.id.action_cursor:
                openCursor();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void openCursor() {
        LayoutParams params = new LayoutParams();
        if (VERSION.SDK_INT >= VERSION_CODES.O) {
            params.type = LayoutParams.TYPE_APPLICATION_OVERLAY;//WindowManager.LayoutParams.TYPE_PHONE;
        } else {
            params.type = LayoutParams.TYPE_PHONE;

        }
        params.format = PixelFormat.TRANSLUCENT;
        params.width = LayoutParams.MATCH_PARENT;
        params.height = LayoutParams.MATCH_PARENT;


        params.flags = LayoutParams.FLAG_NOT_TOUCH_MODAL
                | LayoutParams.FLAG_NOT_FOCUSABLE;
        final WindowManager windowManager = (WindowManager)
                getApplicationContext().getSystemService(Context.WINDOW_SERVICE);

        final View view = LayoutInflater.from(this).inflate(R.layout.cursor, null);

        final View cursor = view.findViewById(R.id.image_view);
        Views.movable(cursor);
        WindowManager.LayoutParams layoutParams = params;
        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        final String key = "position";

        view.findViewById(R.id.add).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                preferences.edit().putString(key, String.format("%d|%d",
                        (int) cursor.getX(), (int) cursor.getY())).apply();

            }
        });
        view.findViewById(R.id.accessibility).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAccessibilityService(MainActivity.this, REQUEST_CODE_ACCESSIBILITY_SERVICE);
            }
        });
        view.findViewById(R.id.close).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                windowManager.removeView(view);
            }
        });
        windowManager.addView(view, layoutParams);
    }

    @Override
    int requestCodePermissions() {
        return 0;
    }
}
