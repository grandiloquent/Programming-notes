package euphoria.psycho.autotoucher;

import android.Manifest;
import android.Manifest.permission;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Build.VERSION_CODES;
import android.os.Bundle;
import android.os.Process;
import android.provider.Settings;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public abstract class Activities extends Activity {

    abstract void initialize();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String[] permissions = needPermissions();
        if (VERSION.SDK_INT >= VERSION_CODES.M
                && permissions != null
                && permissions.length > 0) {
            List<String> shouldPermissions = new ArrayList<>();
            for (String permission : permissions) {
                if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) continue;
                shouldPermissions.add(permission);
            }
            if (shouldPermissions.size() > 0) {
                requestPermissions(shouldPermissions.toArray(new String[0]), requestCodePermissions());
                return;
            }

        }
        initialize();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
//        for (int i = 0, j = grantResults.length; i < j; i++) {
//            if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
//                Toast.makeText(this, permissions[i], Toast.LENGTH_LONG).show();
//                return;
//            }
//        }
        initialize();
    }

    abstract String[] needPermissions();

    abstract int requestCodePermissions();

    public static boolean checkAccessibilityService(Activity context, int requestCode) {
        int result = context.checkCallingOrSelfPermission(permission.BIND_ACCESSIBILITY_SERVICE);
        if (result == PackageManager.PERMISSION_DENIED) {
            context.startActivityForResult(new Intent("android.settings.ACCESSIBILITY_SETTINGS"), requestCode);
            return false;
        }

        return true;
    }

    public static void requestOverlayPermission(Activity context, int requestCode) {
//
        if (!Settings.canDrawOverlays(context)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
            intent.setData(Uri.parse("package:" + context.getPackageName()));

            context.startActivityForResult(intent,
                    requestCode);
        }


    }

    public static void stopSelf() {
        Process.killProcess(Process.myPid());
    }
    //android.settings.action.MANAGE_OVERLAY_PERMISSION


}
