package euphoria.psycho.autotoucher;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build.VERSION;
import android.os.Build.VERSION_CODES;
import android.text.Layout;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;

public class Floatings implements OnTouchListener {
    private View mView;
    private int mResourceId;
    private Context mContext;
    private WindowManager mWindowManager;
    private LayoutParams mLayoutParams;
    private int initialX;
    private int initialY;
    private float initialTouchX;
    private float initialTouchY;


    public Floatings(Context context, int resId) {
        mResourceId = resId;
        mView = LayoutInflater.from(context).inflate(resId, null);
        mView.setOnTouchListener(this);
        mWindowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        mLayoutParams = newLayoutParams();
    }


    public int[] getLocation() {
        int[] location = new int[2];
        mView.getLocationOnScreen(location);
        return location;
    }

    @Override
    public boolean onTouch(View view, MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:

                //remember the initial position.
                initialX = mLayoutParams.x;
                initialY = mLayoutParams.y;

                //get the touch location
                initialTouchX = event.getRawX();
                initialTouchY = event.getRawY();
                return true;
            case MotionEvent.ACTION_MOVE:
                //Calculate the X and Y coordinates of the view.
                mLayoutParams.x = initialX + (int) (event.getRawX() - initialTouchX);
                mLayoutParams.y = initialY + (int) (event.getRawY() - initialTouchY);

                //Update the layout with new X & Y coordinate
                mWindowManager.updateViewLayout(mView, mLayoutParams);
                return true;
        }
        return true;
    }

    public void show() {
        mWindowManager.addView(mView, mLayoutParams);
    }

    public static LayoutParams newLayoutParams() {
        LayoutParams params = new LayoutParams();
        // 对齐方式
        params.gravity = Gravity.TOP;
        // 浮窗层级
        if (VERSION.SDK_INT >= VERSION_CODES.O) {
            params.type = LayoutParams.TYPE_APPLICATION_OVERLAY;//WindowManager.LayoutParams.TYPE_PHONE;
        } else {
            params.type = LayoutParams.TYPE_PHONE;

        }
        // 背景透明
        params.format = PixelFormat.TRANSLUCENT;
        params.width = LayoutParams.WRAP_CONTENT;
        params.height = LayoutParams.WRAP_CONTENT;

        /*// 全屏显示
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        params.height = WindowManager.LayoutParams.MATCH_PARENT;*/

        // 让window不能获得焦点，这样用户快就不能向该window发送按键事件及按钮事件
        //LayoutParams.FLAG_NOT_FOCUSABLE ;
        params.flags = LayoutParams.FLAG_NOT_FOCUSABLE;

        // 让window占满整个手机屏幕，不留任何边界（border）
//        params.flags |= LayoutParams.FLAG_LAYOUT_IN_SCREEN
//                | LayoutParams.FLAG_LAYOUT_INSET_DECOR;
        // window大小不再不受手机屏幕大小限制，即window可能超出屏幕之外，这时部分内容在屏幕之外
        //params.flags |= WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        return params;
    }

}
