package euphoria.psycho.autotoucher;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.view.accessibility.AccessibilityEvent;

import java.util.List;


public class CustomAccessibilityService extends AccessibilityService {
    private static final String TAG = "TAG/" + CustomAccessibilityService.class.getSimpleName();
    private AccessibilityService.GestureResultCallback mGestureResultCallback = new GestureResultCallback() {
        @Override
        public void onCancelled(GestureDescription gestureDescription) {
            super.onCancelled(gestureDescription);
        }

        @Override
        public void onCompleted(GestureDescription gestureDescription) {
            super.onCompleted(gestureDescription);
        }
    };
    SharedPreferences mPreferences;
    View mCursorView;
    LayoutParams mCursorLayoutParams;
    WindowManager mWindowManager;
    GestureResultCallback mCallback;
    List<Pair<Integer, Integer>> mPositions;
    View mAdd;
    Floatings mFloatings;
    int mTapTimeout;

    public void longPress(int x, int y) {
        dispatchGesture(Accessibilities.createClick(x, y, ViewConfiguration.getLongPressTimeout() + 200), null, null);
    }

    public void swipeDown(int x, int y) {
        dispatchGesture(Accessibilities.createSwipe(x, y, x, y + 100), null, null);
    }

    public void swipeUp(int x, int y) {
        dispatchGesture(Accessibilities.createSwipe(x, y, x, y - 100), null, null);
    }

    public void tap(int x, int y, GestureResultCallback callback) {


        dispatchGesture(Accessibilities.createClick(x, y,
                mTapTimeout), callback, null);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {

    }

    @Override
    public void onCreate() {
        super.onCreate();
        mTapTimeout = ViewConfiguration.getTapTimeout() + 50;


        mPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        mPositions = Utils.parsePositions(mPreferences.getString("position", null));

        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        mCursorView = Views.floatingWindow(mWindowManager, R.layout.cursor_view, getApplicationContext());
//        final View cursor = mCursorView.findViewById(R.id.image_view);
//        Views.movable(cursor);
        mCursorView.findViewById(R.id.touch).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.e(TAG, "Debug: onClick, ");
                //int[] location = mFloatings.getLocation();

                tap(203, 304, mCallback);
            }
        });
        mAdd = mCursorView.findViewById(R.id.add);
        mAdd.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                mFloatings = new Floatings(v.getContext(), R.layout.cursor_pointer);
                mFloatings.show();
            }
        });
        mCursorView.findViewById(R.id.close).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //CustomAccessibilityService.this.stopSelf();
                android.os.Process.killProcess(android.os.Process.myPid());

            }
        });
        mCallback = new GestureResultCallback() {
            @Override
            public void onCancelled(GestureDescription gestureDescription) {
                super.onCancelled(gestureDescription);

                Log.e(TAG, "Debug: onCancelled, ");

            }

            @Override
            public void onCompleted(GestureDescription gestureDescription) {
                super.onCompleted(gestureDescription);

                Log.e(TAG, "Debug: onCompleted, ");

            }
        };
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
//        if (mWindowManager != null && mCursorView != null) {
//            mWindowManager.removeView(mCursorView);
//        }


    }

    @Override
    public void onInterrupt() {

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {


        return START_NOT_STICKY;
    }


}
