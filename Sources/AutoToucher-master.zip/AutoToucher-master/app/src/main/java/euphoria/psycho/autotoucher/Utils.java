package euphoria.psycho.autotoucher;

import android.content.Intent;
import android.util.Pair;

import java.util.ArrayList;
import java.util.List;

public class Utils {

    public static List<Pair<Integer, Integer>> parsePositions(String positionString) {
        String[] pieces = positionString.split("\\|");
        List<Pair<Integer, Integer>> positions = new ArrayList<>();

        for (int i = 0, j = pieces.length; i < j; i++) {
            if (i + 1 < j) {
                positions.add(Pair.create(Integer.parseInt(pieces[i]),
                        Integer.parseInt(pieces[++i])));
            }
        }
        return positions;
    }
}
