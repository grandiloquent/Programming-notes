package euphoria.psycho.autotoucher;

import android.accessibilityservice.GestureDescription;
import android.view.ViewConfiguration;

public class TouchEvent {
    private GestureDescription mGestureDescription;
    private int mX;
    private int mY;
    private int mDuration;
    private long mDelay;

    public TouchEvent(int x, int y, long delay) {
        mX = x;
        mY = y;
        mDelay = delay;
        mDuration = ViewConfiguration.getTapTimeout() + 50;
    }

    public long getDelay() {
        return mDelay;
    }

    public GestureDescription getGestureDescription() {
        if (mGestureDescription == null) {
            mGestureDescription = Accessibilities.createClick(mX,
                    mY,
                    mDuration
            );
        }
        return mGestureDescription;
    }

}
