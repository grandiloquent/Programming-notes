package euphoria.psycho.autotoucher;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityService.GestureResultCallback;
import android.accessibilityservice.GestureDescription;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Path;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.ViewConfiguration;

public class Accessibilities {
    public void tap(AccessibilityService accessibilityService,
                    int x,
                    int y,
                    GestureResultCallback callback) {


        accessibilityService.dispatchGesture(Accessibilities.createClick(x, y, ViewConfiguration.getTapTimeout() + 50), callback, null);
    }

    public static GestureDescription createClick(int x, int y, int duration) {
        Path clickPath = new Path();
        clickPath.moveTo(x, y);
        GestureDescription.StrokeDescription clickStroke = new GestureDescription.StrokeDescription(clickPath, 0, duration);
        GestureDescription.Builder clickBuilder = new GestureDescription.Builder();
        clickBuilder.addStroke(clickStroke);
        return clickBuilder.build();
    }

    public static GestureDescription createSwipe(int x1, int y1, int x2, int y2) {
        Path swipePath = new Path();
        swipePath.moveTo(x1, y1);
        swipePath.moveTo(x2, y2);
        GestureDescription.StrokeDescription swipeStroke = new GestureDescription.StrokeDescription(swipePath, 0, 100);
        GestureDescription.Builder swipeBuilder = new GestureDescription.Builder();
        swipeBuilder.addStroke(swipeStroke);
        return swipeBuilder.build();
    }

    public static boolean isAccessibilitySettingsOn(Context context,
                                                    Class<? extends AccessibilityService> clazz) {
        String serviceName = context.getPackageName() + "/" + clazz.getCanonicalName();
        int accessibilityEnable = Settings.Secure.getInt(context.getContentResolver(),
                Settings.Secure.ACCESSIBILITY_ENABLED, 0);
        if (accessibilityEnable == 1) {
            TextUtils.SimpleStringSplitter simpleStringSplitter =
                    new TextUtils.SimpleStringSplitter(':');
            String settingValue = Settings.Secure.getString(context.getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (settingValue != null) {
                simpleStringSplitter.setString(settingValue);
                while (simpleStringSplitter.hasNext()) {
                    String accessibilityService = simpleStringSplitter.next();
                    if (accessibilityService.equalsIgnoreCase(serviceName)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static void openAccessibilitySettingsUi(Activity activity, int requestCode) {
        Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        activity.startActivityForResult(intent, requestCode);
    }
}
