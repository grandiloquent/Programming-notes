#if !defined(BINARY_H)
#define BINARY_H
#include <string>
namespace binary {
int convert(std::string const &text);
}
#endif

namespace binary {
int convert(std::string const &text) {
  int result = 0;
  if (text.length() > sizeof(int) * 8 - 1) {
    return 0;
  }
  for (const char x:text) {
    result <<= 1;
    if (x == '1') {
      result |= 1;
    } else if (x != '0') {
      return 0;
    }
  }
  return result;
}
}
#include <iostream>

int main() {

  std::cout << binary::convert("11") << std::endl;
  return 0;
}