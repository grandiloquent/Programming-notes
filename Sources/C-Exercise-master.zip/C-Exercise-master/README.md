# C++ Exercise

- https://github.com/PacktPublishing/C-Standard-Template-Library-in-Practice
- https://github.com/exercism/cpp 
