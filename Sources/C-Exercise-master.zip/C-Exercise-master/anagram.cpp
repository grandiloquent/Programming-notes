#if  !defined(ANAGRAM_H)
#define ANAGRAM_H
#include <string>
#include <vector>
namespace anagram {
class anagram {
 public:
  anagram(std::string const &subject);
  std::vector<std::string> matches(std::vector<std::string> const &matches);
 private:
  std::string const subject_;
  std::string const key_;
};
}
#endif

#include <algorithm>
#include <cctype>
using namespace std;
namespace {
string to_lower_copy(string const &s) {
  string cpy(s);
  for (auto &c:cpy) {
    c = tolower(c);
  }
  return cpy;
}
string make_key(string const &s) {
  string key{to_lower_copy(s)};
  sort(key.begin(), key.end());
  return key;
}
}
namespace anagram {
anagram::anagram(string const &subject)
    : subject_(subject), key_(make_key(subject)) {
}
vector<string> anagram::matches(vector<string> const &matches) {
  vector<string> result;
  for (string const &s:matches) {
    if (s.length() == key_.length()
        && to_lower_copy(s) != to_lower_copy(subject_)
        && make_key(s) == key_) {
      result.push_back(s);
    }
  }
  return result;
}
}

#include <iostream>
int main() {
  anagram::anagram subject = anagram::anagram("master");
  auto matches = subject.matches({"stream", "pigeon", "maters"});
  for (const string s:matches) {
    std::cout << s << std::endl;
  }
  return 0;
}