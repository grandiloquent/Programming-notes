
#ifndef _TRANSACTION_HPP_
#    define _TRANSACTION_HPP_
#    include <string>
#    include <ctime>
#    include <iostream>
#    define BEGIN_TRANSACTION "BTRANS"
std::string& trim(std::string& s)
{
    s.erase(0, s.find_first_not_of(" \t\n"));
    s.erase(s.find_last_not_of(" \t\n") + 1);
    return s;
}
class Transaction
{
    std::string accountName;
    long double amount;
    std::string memo;
    std::time_t transactionDate;

public:
    Transaction()
        : accountName({})
        , amount{}
        , memo({})
        , transactionDate(time(0))
    {
    }
    Transaction(const std::string& accountName, long double amount, const std::string& memo)
        : accountName(accountName)
        , amount(amount)
        , memo(memo)
        , transactionDate(std::time(0))
    {
    }
    const std::string& getAccountName() const
    {
        return accountName;
    }
    long double getAmount() const
    {
        return amount;
    }
    const std::string& getMemo() const
    {
        return memo;
    }

    time_t getTransactionDate() const
    {
        return transactionDate;
    }

    friend std::ostream& operator<<(std::ostream& os, const Transaction& t);
    friend std::istream& operator>>(std::istream& is, Transaction& t);
};
std::ostream& operator<<(std::ostream& os, const Transaction& t)
{
    os << BEGIN_TRANSACTION << " "
       << t.accountName << " "
       << t.transactionDate << " "
       << t.amount << " "
       << t.memo << "\n";
    return os;
}
std::istream& operator>>(std::istream& is, Transaction& t)
{
    is >> t.accountName;
    is >> t.transactionDate;
    is >> t.amount;
    std::getline(is, t.memo);
    trim(t.memo);
    return is;
}
#endif

#ifndef _ACCOUNT_HPP_
#    define _ACCOUNT_HPP_
#    include <vector>
#    include <algorithm>
#    include <iterator>
#    include <numeric>

#    define BEGIN_ACCOUNT "BACCT"

class Account
{
    std::string name;
    std::vector<Transaction> transactions;

public:
    Account()
        : name({})
        , transactions({})
    {
    }
    Account(const std::string& name)
        : name(name)
        , transactions({})
    {
    }
    const std::string& getName() const
    {
        return name;
    }
    const std::vector<Transaction>& getTransactions() const
    {
        return transactions;
    }
    void addTransaction(Transaction& t)
    {
        transactions.push_back(t);
    }
    long double balance() const
    {
        long double sum = 0;
        sum = std::accumulate(std::begin(transactions), std::end(transactions), sum,
            [](const long double& a, const Transaction& b) {
                return a + b.getAmount();
            });
        return sum;
    }
    friend std::ostream& operator<<(std::ostream& os, const Account& a);
    friend std::istream& operator>>(std::istream& is, Account& a);
};
std::ostream& operator<<(std::ostream& os, const Account& a)
{
    os << BEGIN_ACCOUNT << " "
       << a.name << "\n";
    return os;
}
std::istream& operator>>(std::istream& is, Account& a)
{
    is >> a.name;
    return is;
}
#endif

#include <string>
#include <iostream>
#include <iomanip>

template <typename charT, typename traits = std::char_traits<charT>>
class center_helper
{
    std::basic_string<charT, traits> str_;

public:
    center_helper(std::basic_string<charT, traits> str)
        : str_(str)
    {
    }
    template <typename a, typename b>
    friend std::basic_ostream<a, b>& operator<<(std::basic_ostream<a, b>& s,
        const center_helper<a, b>& c);
};
template <typename charT, typename traits = std::char_traits<charT>>
center_helper<charT, traits> centered(std::basic_string<charT, traits> str)
{
    return center_helper<charT, traits>(str);
}
center_helper<std::string::value_type, std::string::traits_type> centered(
    const std::string& str)
{
    return center_helper<std::string::value_type, std::string::traits_type>(str);
}
template <typename charT, typename traits>
std::basic_ostream<charT, traits>& operator<<(std::basic_ostream<charT, traits>& s,
    const center_helper<charT, traits>& c)
{
    std::streamsize w = s.width();
    if (w > (int)c.str_.length())
    {
        std::streamsize left = (w + c.str_.length()) / 2;
        s.width(left);
        s << c.str_;
        s.width(w - left);
        s << "";
    }
    else
    {
        s << c.str_;
    }
    return s;
}
void printBanner()
{
    std::cout << std::setfill('-');
    std::cout << std::setw(80) << centered(R"x(--------------------------------)x") << "\n";
    std::cout << std::setw(80) << centered(R"x( __  __                         )x") << "\n";
    std::cout << std::setw(80) << centered(R"x(|  \/  |                        )x") << "\n";
    std::cout << std::setw(80) << centered(R"x(| \  / | ___  _ __   ___ _   _  )x") << "\n";
    std::cout << std::setw(80) << centered(R"x(| |\/| |/ _ \| '_ \ / _ \ | | | )x") << "\n";
    std::cout << std::setw(80) << centered(R"x(| |  | | (_) | | | |  __/ |_| | )x") << "\n";
    std::cout << std::setw(80) << centered(R"x(|_|  |_|\___/|_| |_|\___|\__, | )x") << "\n";
    std::cout << std::setw(80) << centered(R"x(                          __/ | )x") << "\n";
    std::cout << std::setw(80) << centered(R"x(                         |___/  )x") << "\n";
    std::cout << std::setw(80) << centered(R"x(--------------------------------)x") << "\n";
    std::cout << std::setfill(' ');
    std::cout << "\n\n\n\n\n\n\n\n\n\n";
}
std::string prompt()
{
    std::string c;
    std::cout << "command> ";
    std::getline(std::cin, c);
    return c;
}
Transaction readTransaction(bool withdraw = false)
{
    std::string account;
    long double amount;
    std::string memo;
    std::cout << std::setw(15) << std::left << "Account name" << std::right << ": ";
    std::cin >> account;
    std::cout << std::setw(15) << std::left << "Amount" << std::right << ": ";
    std::cin >> std::get_money(amount);
    std::cout << std::setw(15) << std::left << "Memo" << std::right << ": ";
    if (withdraw && amount > 0)
    {
        amount = -amount;
    }

    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::getline(std::cin, memo);
    trim(memo);
    Transaction t(account, amount, memo);
    return t;
}
Account readAccount()
{
    std::string accountName;
    std::cout << std::setw(20) << std::left << "New account name" << std::right << ": ";
    std::cin >> accountName;
    Account a(accountName);
    return a;
}
void deleteAccount(std::vector<Account>& accounts)
{
    std::string accountName;
    std::cout << "Accounts avilable: \n";
    for (const Account& a : accounts)
    {
        std::cout << std::setw(30) << a.getName() << ": " << a.getTransactions().size()
                  << " transactions\n";
    }
    std::cout << std::setw(15) << std::left << "Account name" << std::right << ": ";
    std::cin >> accountName;

    for (auto it = std::begin(accounts); it != std::end(accounts);)
    {
        if (std::equal(std::begin((*it).getName()), std::end((*it).getName()), std::begin(accountName)))
        {
            it = accounts.erase(it);
        }
        else
        {
            ++it;
        }
    }
}
void printHelp()
{
    std::string line(80, '-');
    std::cout << std::setw(80) << centered("Commands") << "\n";
    std::cout << line << "\n";
    std::cout << std::setw(20) << "help" << std::setw(50) << "Print Help Message\n";
    std::cout << std::setw(20) << "new" << std::setw(50) << "Create a new account\n";
    std::cout << std::setw(20) << "deposit" << std::setw(50) << "Create a new deposit\n";
    std::cout << std::setw(20) << "widthdraw" << std::setw(50) << "Create a new withdrawal\n";
    std::cout << std::setw(20) << "ledger" << std::setw(50) << "Print out account ledger\n";
    std::cout << std::setw(20) << "delete" << std::setw(50) << "Delete an account and all transactions\n";
    std::cout << std::setw(20) << "quit" << std::setw(50) << "Quit the program and write the data file\n";
    std::cout << "\n\n\n";
}
void addToAccount(Transaction& t, std::vector<Account>& accounts)
{
    std::for_each(std::begin(accounts), std::end(accounts), [&](Account& a) {
        std::string an = t.getAccountName();
        if (std::equal(std::begin(an), std::end(an), std::begin(a.getName())))
        {
            a.addTransaction(t);
        }
    });
}
void printAccountLedger(const Account& a)
{
    std::string line(80, '-');
    std::ostringstream oss;
    oss << "Ledger for " << a.getName();
    std::cout << "\n\n";
    std::cout << std::setw(80) << centered(oss.str()) << "\n";
    std::cout << line << "\n";
    for (const Transaction& t : a.getTransactions())
    {
        std::time_t time = t.getTransactionDate();
        struct tm* date = std::localtime(&time);
        std::cout << std::setw(20) << std::left << std::put_time(date, "%D %r");
        std::cout << std::setw(40) << std::right << t.getMemo();
        std::cout << std::setw(20) << std::right << std::put_money(t.getAmount(), true);
        std::cout << "\n";
    }
    oss.str("");
    oss.clear();
    oss.imbue(std::locale(""));
    oss << "Total: $" << std::put_money(a.balance());
    std::string dashes(oss.str().size(), '-');
    std::cout << std::setw(80) << dashes << "\n";
    std::cout << std::setw(80) << oss.str() << "\n";
}
#define DATA_FILE "money.dat"
using namespace std;
int readInDataFile(vector<Account>& accounts, istream& is)
{
    string leadin;
    int transactionCount = 0;
    while (is)
    {
        is >> leadin;
        if (leadin.empty())
        {
            continue;
        }
        else if (equal(begin(leadin), end(leadin), begin(BEGIN_ACCOUNT)))
        {
            Account a;
            is >> a;
            accounts.push_back(a);
        }
        else if (equal(begin(leadin), end(leadin), begin(BEGIN_TRANSACTION)))
        {
            Transaction t;
            is >> t;
            ++transactionCount;
            for_each(begin(accounts), end(accounts), [&t](Account& a) {
                string an = t.getAccountName();
                if (equal(begin(an), end(an), begin(a.getName())))
                {
                    a.addTransaction(t);
                }
            });
        }
        else
        {
            cerr << "Unknown header field found: " << leadin << "\n";
        }
        leadin.clear();
    }
    return transactionCount;
}
void outputDataToFile(vector<Account>& accounts, ostream& os)
{
    for (Account& a : accounts)
    {
        os << a;
        for (const Transaction& t : a.getTransactions())
        {
            os << t;
        }
    }
}
#include <fstream>

int main()
{

    std::locale loc("");
    cout.imbue(loc);
    cin.imbue(loc);
    bool quit = false;
    vector<Account> accounts;
    ifstream is(DATA_FILE);

    if (is)
    {
        int transactions = readInDataFile(accounts, is);
        cout << "Read in " << transactions << " transactions\n";
    }
    is.close();
    printBanner();

    while (!quit)
    {
        string command = prompt();
        if (command.empty())
        {
            continue;
        }
        else if (equal(begin(command), end(command), begin("quit")))
        {
            quit = true;
            break;
        }
        else if (equal(begin(command), end(command), begin("ledger")))
        {
            for (const Account& a : accounts)
            {
                printAccountLedger(a);
            }
        }
        else if (equal(begin(command), end(command), begin("deposit")))
        {
            Transaction t = readTransaction();
            addToAccount(t, accounts);
            cout << "Deposit complete\n\n\n";
        }
        else if (equal(begin(command), end(command), begin("withdraw")))
        {
            Transaction t = readTransaction(true);
            addToAccount(t, accounts);
            cout << "Widthdraw complete\n\n\n";
        }
        else if (equal(begin(command), end(command), begin("new")))
        {
            Account a = readAccount();
            accounts.push_back(a);
            cout << "Account created\n\n\n";
        }
        else if (equal(begin(command), end(command), begin("delete")))
        {
            deleteAccount(accounts);
            cout << "Account deleted\n\n\n";
        }
        else if (equal(begin(command), end(command), begin("help")))
        {
            printHelp();
        }
        else
        {
            cerr << "Unknown command\n";
        }
    }
    ofstream ofs(DATA_FILE);
    outputDataToFile(accounts, ofs);
    ofs.close();
    return 0;
}