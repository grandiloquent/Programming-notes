#include <iostream>
#include <iterator>
#include <vector>
using namespace std;
int main() {
  vector<int> numbers{1, 2, 3, 4, 5};
  for (auto it = numbers.begin(); it != numbers.end(); ++it) {
    *it *= 10;
  }

  for (auto it = std::prev(numbers.end()); it >= numbers.begin(); --it) {
    *it -= 5;
  }
  for (int i:numbers) {
    cout << i << " ";
  }
  cout << "\n";
  return 0;
}