#ifndef SHARED_H__
#    define SHARED_H__

#    include <string.h>
#    include <stdint.h> // UINTMAX_MAX
#    include <limits.h> // CHAR_BIT

#    if defined(__HP_cc) && (__HP_cc >= 61000)
#        define NORETURN __attribute__((noreturn))
#        define NORETURN_PTR
#    elif defined(__GNUC__) && !defined(NO_NORETURN)
#        define NORETURN __attribute__((__noreturn__))
#        define NORETURN_PTR __attribute__((__noreturn__))
#    elif defined(_MSC_VER)
#        define NORETURN __declspec(noreturn)
#        define NORETURN_PTR
#    else
#        define NORETURN
#        define NORETURN_PTR
#        ifndef __GNUC__
#            ifndef __attribute__
#                define __attribute__(x)
#            endif
#        endif
#    endif
#    define PRIuMAX "I64u"
NORETURN void die(const char* err, ...) __attribute__((format(printf, 1, 2)));

#    define bitsizeof(x) (CHAR_BIT * sizeof(x))

#    define maximum_unsigned_value_of_type(a) \
        (UINTMAX_MAX >> (bitsizeof(uintmax_t) - bitsizeof(a)))

/*
 * Returns true if the multiplication of "a" and "b" will
 * overflow. The types of "a" and "b" must match and must be unsigned.
 * Note that this macro evaluates "a" twice!
 */
#    define unsigned_mult_overflows(a, b) \
        ((a) && (b) > maximum_unsigned_value_of_type(a) / (a))

static inline size_t st_mult(size_t a, size_t b)
{
    if (unsigned_mult_overflows(a, b))
        die("size_t overflow: %" PRIuMAX " * %" PRIuMAX,
            (uintmax_t)a, (uintmax_t)b);
    return a * b;
}

void* xrealloc(void* ptr, size_t size);
void* xrealloc(void* ptr, size_t size)
{
    void* ret;

    //memory_limit_check(size, 0);
    ret = realloc(ptr, size);
    if (!ret && !size)
        ret = realloc(ptr, 1);
    if (!ret)
        die("Out of memory, realloc failed");
    return ret;
}

#    define REALLOC_ARRAY(x, alloc) (x) = xrealloc((x), st_mult(sizeof(*(x)), (alloc)))
#    define MOVE_ARRAY(dst, src, n) move_array((dst), (src), (n), sizeof(*(dst)) + BUILD_ASSERT_OR_ZERO(sizeof(*(dst)) == sizeof(*(src))))

static inline void move_array(void* dst, const void* src, size_t n, size_t size)
{
    if (n)
        memmove(dst, src, st_mult(size, n));
}
#    define alloc_nr(x) (((x) + 16) * 3 / 2)

/**
 * Dynamically growing an array using realloc() is error prone and boring.
 *
 * Define your array with:
 *
 * - a pointer (`item`) that points at the array, initialized to `NULL`
 *   (although please name the variable based on its contents, not on its
 *   type);
 *
 * - an integer variable (`alloc`) that keeps track of how big the current
 *   allocation is, initialized to `0`;
 *
 * - another integer variable (`nr`) to keep track of how many elements the
 *   array currently has, initialized to `0`.
 *
 * Then before adding `n`th element to the item, call `ALLOC_GROW(item, n,
 * alloc)`.  This ensures that the array can hold at least `n` elements by
 * calling `realloc(3)` and adjusting `alloc` variable.
 *
 * ------------
 * sometype *item;
 * size_t nr;
 * size_t alloc
 *
 * for (i = 0; i < nr; i++)
 * 	if (we like item[i] already)
 * 		return;
 *
 * // we did not like any existing one, so add one
 * ALLOC_GROW(item, nr + 1, alloc);
 * item[nr++] = value you like;
 * ------------
 *
 * You are responsible for updating the `nr` variable.
 *
 * If you need to specify the number of elements to allocate explicitly
 * then use the macro `REALLOC_ARRAY(item, alloc)` instead of `ALLOC_GROW`.
 *
 * Consider using ALLOC_GROW_BY instead of ALLOC_GROW as it has some
 * added niceties.
 *
 * DO NOT USE any expression with side-effect for 'x', 'nr', or 'alloc'.
 */
#    define ALLOC_GROW(x, nr, alloc)         \
        do                                   \
        {                                    \
            if ((nr) > alloc)                \
            {                                \
                if (alloc_nr(alloc) < (nr))  \
                    alloc = (nr);            \
                else                         \
                    alloc = alloc_nr(alloc); \
                REALLOC_ARRAY(x, alloc);     \
            }                                \
        } while (0)

#endif