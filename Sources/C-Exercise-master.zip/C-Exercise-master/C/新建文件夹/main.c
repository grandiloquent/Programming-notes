#include <stdio.h>

error_t argz_append(char** pargz, size_t* pargz_len, const char* buf, size_t buf_len)
{
    size_t argz_len;
    char* argz;
    assert(pargz);
    assert(pargz_len);
    assert((*pargz && *pargz_len) || (!*pargz && !*pargz_len));
    if (buf_len == 0)
        return 0;
    argz_len = *pargz_len + buf_len;
    argz = (char*)realloc(*pargz, argz_len);
    if (!argz)
        return ENOMEM;
    memcpy(argz + *pargz_len, buf, buf_len);
    *pargz = argz;
    *pargz_len = argz_len;
    return 0;
}

int main()
{
    char* argz = 0;
    size_t argz_len = 0;
    
    return 0;
}