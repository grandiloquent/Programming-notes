#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

#define isnum(x) ((x) >= '0' && (x) <= '9')

bool iswhitespace(const char* s)
{
    if (!s)
        return true;
    while (*s)
        if (!isspace(*s++))
            return false;

    return true;
}

int is_number_list(const char* str)
{

    const char* tmp = str;
    int r = 0;

    while (*tmp)
    {
        if (!isnum(*tmp))
        {
            if (*tmp == '.' && *tmp != *str)
                r = 1;
            break;
        }
        tmp++;
    }
    if (r)
        return *tmp++ && *tmp == ' ';
    return r;
}

char* toggle_number_list(const char* str)
{
    const char* prefix = "- ";

    char* out = malloc(strlen(str) * 2);
    char* tmp = out;
    char* buf = strdup(str);
    strcpy(buf, str);
    char* tok = strtok(buf, "\n");
    size_t count = 0;
    while (tok)
    {
        if (iswhitespace(tok))
            continue;
        count++;

        int add = !is_number_list(tok);

        if (add)
        {
            char num_buf[10];
            memset(num_buf, 0, 10);
            snprintf(num_buf, 10, "%d. ", count);
            size_t i = 0;
            while (i < 10 && num_buf[i] != 0)
            {
                *tmp++ = num_buf[i++];
            }
        }
        else
        {
            while (*tok && *tok++ != ' ')
            {
            }
        }
        while (*tok && isspace(*tok))
            tok++;
        size_t tok_len = strlen(tok);
        while (tok_len > 0)
        {
            tok_len--;
            if (isspace(*(tok + tok_len)))
                *(tok + tok_len) = 0;
            else
                break;
        }
        while (*tok)
        {

            *tmp++ = *tok;
            tok++;
        }
        *tmp++ = '\n';

        tok = strtok(0, "\n");
    }
    *tmp = 0;
    printf("%s\n", out);

    free(buf);
    return out;
}

int main()
{
    const char* str = "\n1. 012345678\n2. 876543210\nABCDEFGHIJKLMNOPQRSTUVWXY\nabcdefghijklmnopqrstuvwxy\n012345678\n876543210\nABCDEFGHIJKLMNOPQRSTUVWXY\nabcdefghijklmnopqrstuvwxy\n012345678\n876543210\nABCDEFGHIJKLMNOPQRSTUVWXY\nabcdefghijklmnopqrstuvwxy\n012345678\n876543210\nABCDEFGHIJKLMNOPQRSTUVWXY\nabcdefghijklmnopqrstuvwxy\n012345678\n876543210\nABCDEFGHIJKLMNOPQRSTUVWXY\nabcdefghijklmnopqrstuvwxy\n";
    toggle_number_list(str);

    return 0;
}