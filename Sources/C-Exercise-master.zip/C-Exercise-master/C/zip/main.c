// zip.c
#include "zip.h"
#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>

struct files
{
    char** files_name;
    size_t capacity;
    size_t index;
};

int list_directory(char* path, struct files* list)
{

    size_t path_len = strlen(path);

    DIR* dir = opendir(path);

    if (dir)
    {

        struct dirent* dp;
        struct stat s;

        while ((dp = readdir(dir)))
        {
            if (strcmp(dp->d_name, ".") == 0
                || strcmp(dp->d_name, "..") == 0)
                continue;

            size_t len = path_len + 2 + strlen(dp->d_name);
            char* buf = malloc(len);
            memset(buf, 0, len);
            strcat(buf, path);
            strcat(buf, "/");
            strcat(buf, dp->d_name);

            if (stat(buf, &s) == -1)
            {
                free(buf);
                continue;
            }
            if (S_ISDIR(s.st_mode))
            {

                list_directory(buf, list);
            }
            else
            {
                if (list->index + 1 >= list->capacity)
                {
                    list->capacity = list->capacity * 2;
                    list->files_name = realloc(list->files_name, sizeof(char*) * list->capacity);
                }
                //printf("%d %s\n", list->index, buf);

                *(list->files_name + list->index++) = buf;
            }
        }
        closedir(dir);
    }

    free(path);

    return 0;
}
int compress_directory(char* path)
{
    size_t path_len = strlen(path);

    char tmp[path_len + 5];
    memset(tmp, 0, path_len + 5);
    strcat(tmp, path);
    strcat(tmp, ".zip");
    printf("%s\n", tmp);

    struct zip_t* zip = zip_open(tmp, ZIP_DEFAULT_COMPRESSION_LEVEL, 'w');

    struct files list = {
        .files_name = malloc(sizeof(char*) * 10),
        .capacity = 10,
        .index = 0,
    };

    list_directory(path, &list);
    for (size_t i = 0; i < list.index; i++)
    {
        printf("%s %d\n", *(list.files_name + i) + path_len + 1, i);
        zip_entry_open(zip, *(list.files_name + i) + path_len + 1);
        zip_entry_fwrite(zip, *(list.files_name + i));
        zip_entry_close(zip);
        free(*(list.files_name + i));
    }

    free(list.files_name);
    zip_close(zip);
    return 0;
}
int main()
{
    const char* path = "C:/Users/psycho/Desktop/Books/ZIP";

    DIR* dir = opendir(path);
    size_t path_len = path_len;

    if (dir)
    {

        struct dirent* dp;
        struct stat s;

        while ((dp = readdir(dir)))
        {
            if (strcmp(dp->d_name, ".") == 0
                || strcmp(dp->d_name, "..") == 0)
                continue;

            size_t len = path_len + 2 + strlen(dp->d_name);
            char* buf = malloc(len);
            memset(buf, 0, len);
            strcat(buf, path);
            strcat(buf, "/");
            strcat(buf, dp->d_name);

            if (stat(buf, &s) == -1)
            {
                free(buf);
                continue;
            }
            if (S_ISDIR(s.st_mode))
            {

                compress_directory(buf);
            }
        }
        closedir(dir);
    }

    return 0;
}