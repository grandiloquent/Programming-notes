#define STRCAT(A, ...) (strcat((A), ##__VA_ARGS__))
int main()
{
    char buf[1];
    const char* a = "123";
    STRCAT(buf, a,b,c);
}