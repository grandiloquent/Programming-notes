#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>

struct files
{
    char** files_name;
    size_t capacity;
    size_t index;
};

int list_directory(char* path, struct files* list)
{

    DIR* dir = opendir(path);

    if (dir)
    {

        struct dirent* dp;
        struct stat s;

        while ((dp = readdir(dir)))
        {
            if (strcmp(dp->d_name, ".") == 0
                || strcmp(dp->d_name, "..") == 0)
                continue;

            size_t len = strlen(path) + 2 + strlen(dp->d_name);
            char* buf = malloc(len);
            memset(buf, 0, len);
            strcat(buf, path);
            strcat(buf, "/");
            strcat(buf, dp->d_name);

            if (stat(buf, &s) == -1)
            {
                free(buf);
                continue;
            }
            if (S_ISDIR(s.st_mode))
            {

                list_directory(buf, list);
            }
            else
            {
                if (list->index + 1 >= list->capacity)
                {
                    list->capacity = list->capacity * 2;
                    list->files_name = realloc(list->files_name, sizeof(char*) * list->capacity);
                }
                //printf("%d %s\n", list->index, buf);

                *(list->files_name + list->index++) = buf;
            }
        }
        closedir(dir);
    }

    free(path);

    return 0;
}
int main()
{
    const char* path = "C:/Users/psycho/Desktop/Arduino";
    struct files list = {
        .files_name = malloc(sizeof(char*) * 10),
        .capacity = 10,
        .index = 0,
    };

    char* p = strdup(path);

    list_directory(p, &list);
    for (size_t i = 0; i < list.index; i++)
    {
        printf("%s %d\n", *(list.files_name + i) + strlen(path), i);
        free(*(list.files_name + i));
    }

    free(list.files_name);
    return 0;
}