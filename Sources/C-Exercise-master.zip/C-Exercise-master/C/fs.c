#include <dirent.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>
#include <ctype.h>

#define list_for_each_entry(a, b, c) while (0)

int DirectoryExists(const char* s)
{
    struct stat st;
    return stat(s, &st) != -1 && S_ISDIR(st.st_mode);
}
int LastIndexOf(const char* s, char c)
{
    size_t len = strlen(s);
    while (--len)
    {
        if (*(s + len) == c)
            return len;
    }
    return -1;
}
int DeleteDirectory(const char* path)
{
    struct dirent* dp;
    DIR* d;
    struct stat s;

    d = opendir(path);
    if (!d)
    {
        return 1;
    }
    while ((dp = readdir(d)))
    {
        if (strcmp(dp->d_name, ".") == 0 || strcmp(dp->d_name, "..") == 0)
            continue;
        char buf[256];
        memset(buf, 0, 256);
        strcat(buf, path);
        strcat(buf, "/");
        strcat(buf, dp->d_name);
        if (stat(buf, &s) == -1)
            continue;
        if (S_ISDIR(s.st_mode))
        {
            printf("%s\n", buf);
            DeleteDirectory(buf);
        }

        else
        {
            printf("%s\n", buf);
            unlink(buf);
        }
        // if(S_ISDIR(s->st_mode))
        // printf("%s\n", dp->d_name);
    }
    closedir(d);
    rmdir(path);
    return 0;
}
int WalkDirectory(const char* path)
{
    struct dirent* dp;
    DIR* d;
    struct stat s;

    d = opendir(path);
    if (!d)
    {
        return 1;
    }
    while ((dp = readdir(d)))
    {
        if (strcmp(dp->d_name, ".") == 0 || strcmp(dp->d_name, "..") == 0)
            continue;
        char buf[256];
        memset(buf, 0, 256);
        strcat(buf, path);
        strcat(buf, "/");
        strcat(buf, dp->d_name);
        if (stat(buf, &s) == -1)
            continue;
        if (S_ISDIR(s.st_mode))
        {
            continue;
        }
        char c = dp->d_name[0];
        if (isalpha(c))
        {
            c = toupper(c);
        }
        else
        {
            c = '0';
        }
        size_t index = strlen(path);
        buf[index + 1] = c;
        buf[index + 2] = 0;
        if (!DirectoryExists(buf))
            mkdir(buf);
        strcat(buf, "/");
        strcat(buf, dp->d_name);

        char source[256];
        memset(source, 0, 256);
        strcat(source, path);
        strcat(source, "/");
        strcat(source, dp->d_name);

        rename(source, buf);
        printf("%s = %s\n", source, buf);
        // if(S_ISDIR(s->st_mode))
        // printf("%s\n", dp->d_name);
    }
    closedir(d);
    return 0;
}

int main(int argc, char const* argv[])
{
    const char* path = "C:/Users/psycho/Desktop/Books/ZIP";
    //  DeleteDirectory(path);
    WalkDirectory(path);
    return 0;
}