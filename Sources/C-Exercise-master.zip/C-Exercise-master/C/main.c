#include <stdio.h>

int isempty(const char* s)
{
    return s != NULL && *s ? 0 : 1;
}

int main(int argc, char const* argv[])
{
    printf("%d\n", isempty(" 1"));
    return 0;
}