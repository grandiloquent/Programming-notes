#if !defined(BINARY_SEARCH_H)
#define BINARY_SEARCH_H
#include <vector>
#include <cstddef>
namespace binary_search {
using std::size_t;
size_t find(std::vector < int >
const &,int const);
}
#endif

#include <stdexcept>

namespace binary_search
{

bool is_value_in_range(std::vector<int> const& data, int const value)
{
return ((data.front() <= value) && (value <= data.back()));
}

size_t find(std::vector<int> const& data, int const value)
{
if(data.empty() || !is_value_in_range(data, value))
{
throw std::domain_error("Value not in input vector!");
}

size_t lpos {0};
size_t rpos {data.size() - 1};
size_t mid  {0};

while (lpos <= rpos)
{
mid = lpos + ((rpos - lpos) / 2);

if (data.at(mid) == value)
{
return mid;
}

if (value < data.at(mid))
{
rpos = mid - 1;
}

if (value > data.at(mid))
{
lpos = mid + 1;
}
}

throw std::domain_error("Value not in input vector!");
}

} // namespace binary_search


#include <iostream>

int main(){
  const std::vector<int> data{1,3,,4,6,8,9,11};
  const std::size_t actual=binary_search::find(data,11);


  return 0;
}