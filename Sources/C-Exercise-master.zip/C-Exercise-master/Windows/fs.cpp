
// --std=c++17 -lstdc++fs
#include <iostream>
#include <filesystem>
#include <cctype>

namespace fs = std::filesystem;

void deleteRecycle()
{
    fs::path desktop("C:\\Users\\psycho\\Desktop\\Recycle");
    for (auto& p : fs::directory_iterator(desktop))
    {
        if (fs::is_directory(p))
            fs::remove_all(p);
        else
            fs::remove(p);
        std::cout << p.path() << std::endl;
    }
}
void moveFiles()
{
    fs::path desktop("C:\\Users\\psycho\\Desktop\\Books\\ZIP");
    for (auto& p : fs::directory_iterator(desktop))
    {
        if (!fs::is_regular_file(p))
            continue;
        char f = p.path().filename().string().at(0);
        char c = f;

        if (!std::isupper(f))
            c = std::toupper(c);
        if(!std::isalpha(f))
            c='0';

        fs::path targetDirectory(desktop);
        targetDirectory += "\\";
        targetDirectory += c;

        fs::create_directory(targetDirectory);
        targetDirectory /= p.path().filename();
        fs::rename(p, targetDirectory);
        std::cout << targetDirectory << std::endl;
    }
}

int main(int argc, char const* argv[])
{
    //deleteRecycle();
    moveFiles();
    return 0;
}