
// --std=c++17 -lstdc++fs
#include <iostream>
#include <filesystem>
#include <assert.h>
#include <algorithm>
#include <numeric> // std::accumulate

using namespace std;
namespace fs = std::filesystem;

void printSize(std::ostream& stream, size_t totalSize)
{
    static const char* SIZES[] = { "B", "kB", "MB", "GB", "TB", "ZB" };
    int div = 0;
    auto size = static_cast<double>(totalSize);
    while (size >= 1024 && div < static_cast<int>(sizeof SIZES / sizeof *SIZES))
    {
        div++;
        size /= 1024.0; // >>= 10;
    }
    stream << size << SIZES[div];
}
size_t getDirectorySize(const fs::path& path)
{

  assert(fs::is_directory(path));
  fs::recursive_directory_iterator dir_iterator(path);
  return std::accumulate(begin(dir_iterator), end(dir_iterator), 0,
        [](int size, const auto& it) {
          return size + (fs::is_regular_file(it.path()) ? fs::file_size(it.path()) : 0);
        });
}
unsigned long calculateDirectory(const string& dir)
{
    long long unsigned int totalSize{ 0ULL };
    for (auto& p : fs::recursive_directory_iterator(dir))
    {
        if (p.is_regular_file())
        {
            std::cout << static_cast<unsigned long>(fs::file_size(p))
                      << " + "
                      << totalSize;
            totalSize += static_cast<long unsigned int>(fs::file_size(p));
            std::cout << " = " << totalSize << std::endl;
        }
        else if (p.is_directory())
        {
        }
    }
    std::cout << totalSize << std::endl;
    return totalSize;
}

int main(int argc, char const* argv[])
{
    const string dir{ "C:\\Users\\psycho\\Downloads\\1" };
    // std::uintmax_t totalSize = calculateDirectory(dir);
    // std::stringstream sizeStr;
    // printSize(sizeStr, totalSize);
    
    std::cout <<getDirectorySize(dir);
    return 0;
}