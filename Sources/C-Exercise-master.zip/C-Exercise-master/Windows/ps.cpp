#include <windows.h>
#include <iostream>
#include <vector>
#include <psapi.h>
#include <iterator> // std::ostream_iterator

// #define DEBUG
// https://docs.microsoft.com/en-us/windows/win32/psapi/enumerating-all-processes

bool PrintProcessInformation(DWORD pid, std::vector<std::string>& processesName)
{
#ifdef DEBUG
    std::cout << "[PrintProcessInformation] " << pid << std::endl;
#endif

    HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ,
        FALSE, pid);

    if (hProcess != NULL)
    {
        HMODULE hMod;
        DWORD cbNeed;

        if (EnumProcessModules(hProcess, &hMod, sizeof(hMod), &cbNeed))
        {
            char szProcessName[MAX_PATH];
            GetModuleBaseName(hProcess, hMod, szProcessName, MAX_PATH);
            processesName.push_back(szProcessName);
        }
        else
        {
            std::cout << "[PrintProcessInformation] EnumProcessModules " << pid << " Failed." << std::endl;
        }
    }
    else
    {
        std::cout << "[PrintProcessInformation] OpenProcess " << pid << " Failed." << std::endl;
    }
    CloseHandle(hProcess);
    return false;
}

bool GetProcesses(std::vector<DWORD>* processes)
{

    if (!processes)
    {
        return false;
    }
    processes->resize(512);
    DWORD bytes_returned;
    DWORD current_byte_size;
    do
    {
        processes->resize(processes->size() * 2);
        current_byte_size = processes->size() * sizeof(DWORD);
        if (!EnumProcesses(reinterpret_cast<DWORD*>(processes->data()),
                current_byte_size, &bytes_returned))
        {
            std::cout << "Failed to enumerate processes";
            return false;
        }
    } while (bytes_returned == current_byte_size);
    size_t processes_size = bytes_returned / sizeof(DWORD);
    processes->resize(processes_size);
    return true;
}

int main(int argc, char const* argv[])
{
    std::vector<DWORD> processes;
    bool result = GetProcesses(&processes);
    std::cout << std::boolalpha;
    std::cout << "[GetProcesses] " << result << std::endl;
    // std::copy(std::begin(processes), std::end(processes), std::ostream_iterator<DWORD>(std::cout, " "));

    std::vector<std::string> v;
    for (auto& pid : processes)
    {
        PrintProcessInformation(pid, v);
    }
    std::copy(std::begin(v), std::end(v), std::ostream_iterator<std::string>(std::cout, "\n"));

    return 0;
}