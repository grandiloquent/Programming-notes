package euphoria.psycho.common;

import java.util.List;

public class Lists {

    public static <T> void addAll(List<T> list, T[] ts) {
        for (T t : ts) {
            list.add(t);
        }
    }
}
