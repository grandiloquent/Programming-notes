package euphoria.psycho.common;

public class Predictions {
    public static int compare(boolean x, boolean y) {
        return (x == y) ? 0 : (x ? 1 : -1);
    }
}
