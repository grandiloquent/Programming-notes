package euphoria.psycho.common;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build.VERSION;
import android.os.Build.VERSION_CODES;

import java.util.ArrayList;
import java.util.List;

public class Activities {

    public static boolean requestPermissions(Activity activity, String[] permissions, int requestCode) {
        if (VERSION.SDK_INT >= VERSION_CODES.M) {
            List<String> needPermissions = new ArrayList<>();

            for (String permission : permissions) {

                if (activity.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED)
                    continue;

                needPermissions.add(permission);
            }
            if (needPermissions.size() == 0) return false;

            activity.requestPermissions(needPermissions.toArray(new String[0]), requestCode);
            return true;
        }
        return false;
    }

}
