package euphoria.psycho.common;

import android.annotation.TargetApi;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.pdf.PdfRenderer;
import android.graphics.pdf.PdfRenderer.Page;
import android.os.Build.VERSION_CODES;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.IOException;

public class Pdfs {

    @TargetApi(VERSION_CODES.LOLLIPOP)
    public static Bitmap extractPdfToImage(File file, int index) throws IOException {
        ParcelFileDescriptor descriptor = ParcelFileDescriptor.open(file,
                ParcelFileDescriptor.MODE_READ_ONLY);
        PdfRenderer pdfRenderer = new PdfRenderer(descriptor);

        Page page = pdfRenderer.openPage(index);

        Bitmap bitmap = Bitmap.createBitmap(page.getWidth(),
                page.getHeight(), Config.ARGB_8888);

        page.render(bitmap, null, null, Page.RENDER_MODE_FOR_DISPLAY);

        page.close();
        return bitmap;


    }
}

