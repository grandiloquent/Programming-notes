package euphoria.psycho.filemanager;

import android.Manifest;
import android.Manifest.permission;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.preference.PreferenceManager;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.shockwave.pdfium.PdfDocument;
import com.shockwave.pdfium.PdfiumCore;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import euphoria.psycho.common.Activities;
import euphoria.psycho.common.Bitmaps;
import euphoria.psycho.common.Contexts;
import euphoria.psycho.common.Files;
import euphoria.psycho.common.Keys;
import euphoria.psycho.common.Pdfs;
import euphoria.psycho.common.Strings;

public class PDFActivity extends AppCompatActivity implements OnItemClickListener {

    private static final int MENU_CONTEXT_EXTRACT_PDF_TO_IMAGE = 928;
    private static final int REQUEST_CODE_PERMISSION = 956;
    private ListView mListView;
    private FileAdapter mFileAdapter;
    private File mCurrentDirectory;
    private SharedPreferences mPreferences;


    private void initialize() {

        setContentView(R.layout.activity_pdf);
        mPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        String directory = mPreferences.getString(Keys.KEY_DIRECTORY, Environment.getExternalStorageDirectory().getAbsolutePath());

        mCurrentDirectory = new File(directory);

        mFileAdapter = new FileAdapter();
        initializeListView();
        refresh();
    }

    private void initializeListView() {

        mListView = findViewById(R.id.listView);
        mListView.setAdapter(mFileAdapter);
        mListView.setOnItemClickListener(this);
        registerForContextMenu(mListView);
    }

    private void refresh() {
        mFileAdapter.loadDirectory(mCurrentDirectory);
    }

    private void showDialog(final File file) {
        final EditText editText = new EditText(this);

        new AlertDialog.Builder(this)
                .setView(editText)
                .setPositiveButton(android.R.string.ok, new OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int value = Strings.parseIntSafely(editText.getText().toString(), -1);
                        try {
                            Bitmap bitmap = extractPdfToImage(PDFActivity.this, file, value);
                            File out = new File(file.getParentFile(), file.getName() + ".jpg");
                            Bitmaps.saveAsJpg(bitmap, out);
                            bitmap.recycle();
                            refresh();
                        } catch (Exception e) {
                            Contexts.toast(editText.getContext(), e.getMessage());
                        }
                    }
                })
                .show();
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo menuInfo = (AdapterContextMenuInfo) item.getMenuInfo();
        switch (item.getItemId()) {
            case MENU_CONTEXT_EXTRACT_PDF_TO_IMAGE:
                showDialog(mFileAdapter.getItem(menuInfo.position));
                break;
        }
        return super.onContextItemSelected(item);
    }

    @Override
    protected void onCreate(@Nullable
                                    Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!Activities.requestPermissions(this, new String[]{
                permission.WRITE_EXTERNAL_STORAGE
        }, REQUEST_CODE_PERMISSION)) {
            initialize();
        }
    }

    private Bitmap extractPdfToImage(Context context, File file, int pageNum) throws Exception {
        ParcelFileDescriptor fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);

        PdfiumCore pdfiumCore = new PdfiumCore(context);
        PdfDocument pdfDocument = pdfiumCore.newDocument(fd);

        pdfiumCore.openPage(pdfDocument, pageNum);

        int width = pdfiumCore.getPageWidth(pdfDocument, pageNum);
        int height = pdfiumCore.getPageHeight(pdfDocument, pageNum);

        // ARGB_8888 - best quality, high memory usage, higher possibility of OutOfMemoryError
        // RGB_565 - little worse quality, twice less memory usage
        Bitmap bitmap = Bitmap.createBitmap(width, height,
                Config.ARGB_8888);
        pdfiumCore.renderPageBitmap(pdfDocument, bitmap, pageNum, 0, 0,
                width, height);
        //if you need to render annotations and form fields, you can use
        //the same method above adding 'true' as last param


        pdfiumCore.closeDocument(pdfDocument); // important!
        return bitmap;

    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(0, MENU_CONTEXT_EXTRACT_PDF_TO_IMAGE, 0, "Extract PDF To JPG");
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        File file = mFileAdapter.getItem(position);
        if (file.isDirectory()) {
            mCurrentDirectory = file;
            refresh();
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        initialize();
    }

    private static class FileAdapter extends BaseAdapter

    {

        private List<File> mFiles = new ArrayList<>();

        public void loadDirectory(File directory) {
            if (mFiles.size() > 0) mFiles.clear();
            File[] files = directory.listFiles();
            if (files != null && files.length > 0) {
                Files.sortFiles(files, true, 0);

                Collections.addAll(mFiles, files);
            }
            notifyDataSetChanged();


        }

        @Override
        public int getCount() {
            return mFiles.size();
        }

        @Override
        public File getItem(int position) {
            return mFiles.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, android.view.View convertView, ViewGroup parent) {
            ViewHolder viewHolder;
            if (convertView == null) {
                convertView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_pdf, parent, false);

                viewHolder = new ViewHolder();
                viewHolder.title = convertView.findViewById(R.id.textView);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            viewHolder.title.setText(mFiles.get(position).getName());
            return convertView;
        }
    }

    private static class ViewHolder {
        TextView title;
    }

    @Override
    protected void onPause() {
        super.onPause();
        String preDirectory = mPreferences.getString(Keys.KEY_DIRECTORY, null);
        if (preDirectory == null || !preDirectory
                .equals(mCurrentDirectory.getAbsolutePath())) {
            mPreferences
                    .edit()
                    .putString(Keys.KEY_DIRECTORY, mCurrentDirectory.getAbsolutePath()).apply();
        }

    }

    @Override
    public void onBackPressed() {
        File parent = mCurrentDirectory.getParentFile();
        if (parent != null && parent.getAbsolutePath().startsWith(Environment.getExternalStorageDirectory().getAbsolutePath())) {
            mCurrentDirectory = parent;
            refresh();

        } else
            super.onBackPressed();
    }
}

