package euphoria.psycho.filemanager;

public interface FileDelegate {
}
