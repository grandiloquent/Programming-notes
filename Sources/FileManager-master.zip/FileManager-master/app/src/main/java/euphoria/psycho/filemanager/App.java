package euphoria.psycho.filemanager;

import android.app.Application;
import android.content.Intent;
import android.util.Log;

import java.lang.Thread.UncaughtExceptionHandler;

import euphoria.psycho.base.ContextUtils;
import euphoria.psycho.common.Contexts;
import euphoria.psycho.common.Strings;

public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        ContextUtils.initApplicationContext(this);

//        Thread.setDefaultUncaughtExceptionHandler(new UncaughtExceptionHandler() {
//            @Override
//            public void uncaughtException(Thread t, Throwable e) {
//
//                StringBuilder sb = new StringBuilder();
//                String message = e.getMessage();
//                if (!Strings.isNullOrWhiteSpace(message)) {
//                    sb.append("Meassge: ").append(message).append('\n');
//                }
//                String cause = e.getCause().getMessage();
//                if (!Strings.isNullOrWhiteSpace(cause)) {
//                    sb.append("Cause: ").append(cause).append('\n');
//                }
//                Intent reportActivity = new Intent(App.this, ReportActivity.class);
//                reportActivity.putExtra("message", sb.toString()) ;
//                App.this.startActivity(reportActivity);
//            }
//        });
    }
}
