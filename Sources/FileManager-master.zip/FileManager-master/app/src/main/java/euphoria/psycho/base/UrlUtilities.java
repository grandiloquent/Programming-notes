package euphoria.psycho.base;

import android.text.TextUtils;

public class UrlUtilities {
    /**
     * This function works by calling net::registry_controlled_domains::GetDomainAndRegistry
     *
     * @param uri                      A URI
     * @param includePrivateRegistries Whether or not to consider private registries.
     * @return The registered, organization-identifying host and all its registry information, but
     * no subdomains, from the given URI. Returns an empty string if the URI is invalid, has no host
     * (e.g. a file: URI), has multiple trailing dots, is an IP address, has only one subcomponent
     * (i.e. no dots other than leading/trailing ones), or is itself a recognized registry
     * identifier.
     */
    public static String getDomainAndRegistry(String uri, boolean includePrivateRegistries) {
        if (TextUtils.isEmpty(uri)) return uri;
        return uri;//nativeGetDomainAndRegistry(uri, includePrivateRegistries);
    }
}
