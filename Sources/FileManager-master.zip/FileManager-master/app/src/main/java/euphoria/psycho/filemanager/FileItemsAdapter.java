package euphoria.psycho.filemanager;

import android.content.Context;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import euphoria.psycho.common.Contexts;

public class FileItemsAdapter extends RecyclerView.Adapter<ViewHolder> {
    private List<FileItem> mFileItems = new ArrayList<>();
    private final Context mContext;

    public FileItemsAdapter(Context context) {
        mContext = context;
    }

    @Override
    public int getItemCount() {
        return 0;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }
}
