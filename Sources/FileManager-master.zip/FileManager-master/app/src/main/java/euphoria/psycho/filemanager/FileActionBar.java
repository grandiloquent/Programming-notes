package euphoria.psycho.filemanager;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MenuItem;

import androidx.appcompat.widget.Toolbar.OnMenuItemClickListener;
import euphoria.psycho.widget.selection.SelectableListToolbar;

public class FileActionBar extends SelectableListToolbar<FileItem> implements OnMenuItemClickListener {

    private FileDelegate mDelegate;

    public FileActionBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        setNavigationOnClickListener(this);
        inflateMenu(R.menu.file_action_bar_menu);
        setOnMenuItemClickListener(this);
    }

    public void onFileDelegateInitialized(FileDelegate delegate) {
        mDelegate = delegate;
        getMenu().setGroupEnabled(R.id.selection_mode_menu_group, true);
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        return false;
    }
}
