package euphoria.psycho.filemanager;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.io.File;

import euphoria.psycho.filemanager.LargeIconBridge.LargeIconCallback;
import euphoria.psycho.widget.selection.SelectableListLayout;
import euphoria.psycho.widget.selection.SelectableListToolbar.SearchDelegate;
import euphoria.psycho.widget.selection.SelectionDelegate;

public class FileManager implements FileCoordinator, SearchDelegate, FileDelegate {

    private Activity mActivity;
    private ViewGroup mMainView;
    private SelectableListLayout<FileItem> mSelectableListLayout;
    private FileActionBar mToolbar;
    private SelectionDelegate<FileItem> mSelectionDelegate;


    public FileManager(MainActivity activity) {
        mActivity = activity;

        mSelectionDelegate = new SelectionDelegate<FileItem>() {
            @Override
            public boolean toggleSelectionForItem(FileItem item) {
                return super.toggleSelectionForItem(item);
            }
        };
        mMainView = (ViewGroup) LayoutInflater.from(activity).inflate(R.layout.file_main, null);
        mSelectableListLayout = mMainView.findViewById(R.id.selectable_list);
        mSelectableListLayout.initializeEmptyView(
                R.string.download_manager_no_downloads, R.string.download_manager_no_downloads
        );
        mToolbar = (FileActionBar) mSelectableListLayout.initializeToolbar(
                R.layout.file_action_bar, mSelectionDelegate, 0, R.id.normal_menu_group,
                R.id.selection_mode_menu_group, null, true, false
        );
        mToolbar.initializeSearchView(this, R.string.bookmark_action_bar_search, R.id.search_menu_id);
        mToolbar.onFileDelegateInitialized(this);
        //mSelectableListLayout.configureWideDisplayStyle();

    }

    private LargeIconBridge mLargeIconBridge;

    public LargeIconBridge getLargeIconBridge() {
        return mLargeIconBridge;
    }

    @Override
    public void onEndSearch() {

    }

    @Override
    public void onSearchTextChanged(String query) {

    }

    @Override
    public ViewGroup getView() {
        return mMainView;
    }
}
