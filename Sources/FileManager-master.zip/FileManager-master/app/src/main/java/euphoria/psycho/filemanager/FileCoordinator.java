package euphoria.psycho.filemanager;

import android.view.ViewGroup;

public interface FileCoordinator {

    ViewGroup getView();
}
