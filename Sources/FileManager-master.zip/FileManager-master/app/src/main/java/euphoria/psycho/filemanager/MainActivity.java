package euphoria.psycho.filemanager;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.Nullable;

public class MainActivity extends Activity {
    private FileCoordinator mFileCoordinator;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mFileCoordinator = new FileManager(this);
        setContentView(mFileCoordinator.getView());
    }

}
