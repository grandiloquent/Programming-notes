package euphoria.psycho.filemanager;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class ReportActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        String message = getIntent().getStringExtra("message");
        TextView textView = findViewById(R.id.textView);
        textView.setText(message);
    }
}
