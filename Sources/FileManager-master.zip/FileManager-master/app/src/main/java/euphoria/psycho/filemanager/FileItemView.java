package euphoria.psycho.filemanager;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.core.view.ViewCompat;
import androidx.vectordrawable.graphics.drawable.VectorDrawableCompat;
import euphoria.psycho.base.ApiCompatibilityUtils;
import euphoria.psycho.base.ViewUtils;
import euphoria.psycho.filemanager.LargeIconBridge.LargeIconCallback;
import euphoria.psycho.widget.RoundedIconGenerator;
import euphoria.psycho.widget.selection.SelectableItemView;

public class FileItemView extends SelectableItemView<FileItem> implements LargeIconCallback {
    private final int mDisplayedIconSize;
    private final int mEndPadding;
    private final RoundedIconGenerator mIconGenerator;
    private final int mMinIconSize;
    private ImageButton mRemoveButton;
    private View mContentView;
    private FaviconHelper mFaviconHelper;
    private boolean mIsItemRemoved;
    private boolean mRemoveButtonVisible;
    private VectorDrawableCompat mBlockedVisitDrawable;


    private FileManager mFileManager;

    public FileItemView(Context context, AttributeSet attrs) {
        super(context, attrs);

        mMinIconSize = getResources().getDimensionPixelSize(R.dimen.default_favicon_min_size);
        mDisplayedIconSize = getResources().getDimensionPixelSize(R.dimen.default_favicon_size);
        mIconGenerator = ViewUtils.createDefaultRoundedIconGenerator(getResources(), true);
        mEndPadding = context.getResources().getDimensionPixelSize(R.dimen.selectable_list_layout_row_padding);
        mIconColorList = AppCompatResources.getColorStateList(context, R.color.default_icon_color_inverse);
    }

    public void remove() {
        if (getItem() == null || mIsItemRemoved) return;
        mIsItemRemoved = true;
        getItem().remove();
    }

    private void requestIcon() {
        if (mFileManager == null || mFileManager.getLargeIconBridge() == null) return;
        mFileManager.getLargeIconBridge().getLargeIconForUrl(getItem().getUrl(), mMinIconSize, this);
        
    }

    public void setFaviconHelper(FaviconHelper faviconHelper) {
        mFaviconHelper = faviconHelper;
    }

    public void setFileManager(FileManager manager) {
        getItem().setFileManager(manager);
        if (mFileManager == manager) return;
        mFileManager = manager;
        if (!getItem().wasBlockedVisit()) requestIcon();

    }

    private void updateRemoveButtonVisibility() {
        int removeButtonVisibility = mRemoveButtonVisible ? View.VISIBLE : View.INVISIBLE;
        mRemoveButton.setVisibility(removeButtonVisibility);
        int endPadding = removeButtonVisibility == View.GONE ? mEndPadding : 0;
        ViewCompat.setPaddingRelative(mContentView, ViewCompat.getPaddingStart(mContentView),
                mContentView.getPaddingTop(), endPadding, mContentView.getPaddingBottom());
    }

    @Override
    protected void onClick() {
        if (getItem() != null) getItem().open();

    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        mIconView.setImageResource(R.drawable.default_favicon);
        mContentView = findViewById(R.id.content);
        mRemoveButton = findViewById(R.id.remove);
        mRemoveButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                remove();
            }
        });
        updateRemoveButtonVisibility();


    }

    @Override
    public void onLargeIconAvailable(@Nullable Bitmap icon, int fallbackColor, boolean isFallbackColorDefault, int iconType) {
        if (icon == null) {
            mIconGenerator.setBackgroundColor(fallbackColor);
            icon = mIconGenerator.generateIconForUrl(getItem().getUrl());
            setIconDrawable(new BitmapDrawable(getResources(), icon));
        } else {
            setIconDrawable(ViewUtils.createRoundedBitmapDrawable(
                    Bitmap.createScaledBitmap(icon, mDisplayedIconSize, mDisplayedIconSize, false),
                    ViewUtils.DEFAULT_FAVICON_CORNER_RADIUS
            ));
        }
    }

    @Override
    public void setItem(FileItem item) {
        if (getItem() == item) return;
        super.setItem(item);
        mTitleView.setText(item.getTitle());
        mDescriptionView.setText(item.getDomain());
        mIsItemRemoved = false;
        if (item.wasBlockedVisit()) {
            if (mBlockedVisitDrawable == null) {
                mBlockedVisitDrawable = VectorDrawableCompat.create(
                        getContext().getResources(), R.drawable.ic_block_red,
                        getContext().getTheme()
                );
            }
            setIconDrawable(mBlockedVisitDrawable);
            mTitleView.setTextColor(ApiCompatibilityUtils.getColor(getResources(), R.color.default_red));
        } else {
            setIconDrawable(mFaviconHelper.getDefaultFaviconDrawable(getContext(), item.getUrl(), true));
            if (mFileManager != null) requestIcon();
            mTitleView.setTextColor(ApiCompatibilityUtils.getColor(getResources(), R.color.default_text_color));
        }
    }
}
