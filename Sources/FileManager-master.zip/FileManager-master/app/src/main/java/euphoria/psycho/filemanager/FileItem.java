package euphoria.psycho.filemanager;

public class FileItem {
    public void remove() {

    }

    public boolean wasBlockedVisit() {
        return true;
    }

    public String getUrl() {
        return null;
    }

    public void open() {

    }

    public void setFileManager(FileManager manager) {

    }

    public String getTitle() {
        return null;
    }

    public String getDomain() {
        return null;
    }
}
