package euphoria.psycho.filemanager;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

import androidx.annotation.ColorInt;
import euphoria.psycho.base.ApiCompatibilityUtils;

public class FaviconHelper {
    private Bitmap mDefaultDarkBitmap;

    private Bitmap createBitmap(Context context, String url, boolean useDarkIcon) {
        Bitmap origBitmap =
                BitmapFactory.decodeResource(context.getResources(), R.drawable.default_favicon);
        Bitmap tintedBitmap = Bitmap.createBitmap(
                origBitmap.getWidth(), origBitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(tintedBitmap);
        @ColorInt
        int tintColor = ApiCompatibilityUtils.getColor(context.getResources(),
                useDarkIcon ? R.color.default_icon_color : R.color.default_icon_color_white);
        Paint p = new Paint();
        p.setColorFilter(new PorterDuffColorFilter(tintColor, PorterDuff.Mode.SRC_IN));
        c.drawBitmap(origBitmap, 0f, 0f, p);
        return tintedBitmap;
    }

    public Bitmap getDefaultFaviconBitmap(Context context, String url, boolean useDarkIcon) {
        if (mDefaultDarkBitmap == null) {
            mDefaultDarkBitmap = createBitmap(context, url, useDarkIcon);
        }
        return mDefaultDarkBitmap;
    }

    /**
     * Generate a default favicon drawable for the given URL.
     *
     * @param context     The context used to fetch the default icons.
     * @param url         The URL of the page whose icon is being generated.
     * @param useDarkIcon Whether a dark icon should be used.
     * @return The favicon.
     */
    public Drawable getDefaultFaviconDrawable(
            Context context, String url, boolean useDarkIcon) {
        return new BitmapDrawable(
                context.getResources(), getDefaultFaviconBitmap(context, url, useDarkIcon));
    }

}
