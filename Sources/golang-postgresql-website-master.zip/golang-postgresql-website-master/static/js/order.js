;
(function () {
    'use strict';


    var Order = function Order() {
        this.init();

    };
    window['Order'] = Order;

    Order.prototype.init = function () {

        this.recName_ = document.getElementById('recName');
        if (!this.recName_) {
            return;
        }
        this.recPhone_ = document.getElementById('recPhone');
        this.recAddrDetail_ = document.getElementById('recAddrDetail');

        var recName = __.getItem('recName');
        this.recName_.addEventListener('change', function (event) {
            __.setItem('recName', event.target.value);
        });
        if (recName) {
            this.recName_.value = recName;
        }
        var recPhone = __.getItem('recPhone');
        this.recPhone_.addEventListener('change', function (event) {
            __.setItem('recPhone', event.target.value);
        });
        if (recPhone) {
            this.recPhone_.value = recPhone;
        }
        var recAddrDetail = __.getItem('recAddrDetail');
        this.recAddrDetail_.addEventListener('change', function (event) {
            __.setItem('recAddrDetail', event.target.value);
        });
        if (recAddrDetail) {
            this.recAddrDetail_.value = recAddrDetail;
        }

        this.saveInfoBtn_ = document.getElementById('saveInfoBtn');
        var that = this;
        this.saveInfoBtn_.addEventListener('click', function (event) {
            that.submit();
        });

        this.m_header_bar_back_ = document.querySelector('.m_header_bar_back');
        this.m_header_bar_back_.addEventListener('click', function (event) {
            history.back();
        });

    };
    Order.prototype.submit = function () {
        var url = '/commodities/api/order';

        var m = window.location.search.match("(?<=uid=)[a-z]{6}");
        if (!m) {
            return
        }
        var uid = m[0];

        var data = [uid, this.recName_.value, this.recPhone_.value, this.recAddrDetail_.value];

        fetch(url, {
            method: 'POST', // or 'PUT'
            body: JSON.stringify(data), // data can be `string` or {object}!
            headers: {
                'Content-Type': 'application/json'
            }
        }).then(function (res) {
            return res.json();
        })
            .then(function (response) {
                __.toast("订单已成功提交。", function () {
                    window.location = "../commodities";
                });
            })
            .catch(function (error) {

            });


    };
    new Order();

})();

 