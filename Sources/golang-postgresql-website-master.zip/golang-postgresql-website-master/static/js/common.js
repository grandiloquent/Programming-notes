;(function () {
    function forEach(array, fn) {
        for (var i = 0; i < array.length; i++)
            fn(array[i])
    }


    // https://github.com/Apress/beg-functional-javascript/blob/master/9781484226551/chap07/anto_aravinth-functional-es6-c471e350e983/lib/es6-functional.js


    function click(selector, event) {
        var element = document.querySelector(selector);
        element && element.addEventListener('click', event);
    }

    function clipboard(input) {
        var element = document.createElement('textarea');
        var previouslyFocusedElement = document.activeElement;
        element.value = input;
        // Prevent keyboard from showing on mobile
        element.setAttribute('readonly', '');
        element.style.contain = 'strict';
        element.style.position = 'absolute';
        element.style.left = '-9999px';
        element.style.fontSize = '12pt'; // Prevent zooming on iOS
        var selection = document.getSelection();
        var originalRange = false;
        if (selection.rangeCount > 0) {
            originalRange = selection.getRangeAt(0);
        }
        document.body.append(element);
        element.select();
        // Explicit selection workaround for iOS
        element.selectionStart = 0;
        element.selectionEnd = input.length;
        var isSuccess = false;
        try {
            isSuccess = document.execCommand('copy');
        } catch (_) {
        }
        element.remove();
        if (originalRange) {
            selection.removeAllRanges();
            selection.addRange(originalRange);
        }
        // Get the focus back on the previously focused element, if any
        if (previouslyFocusedElement) {
            previouslyFocusedElement.focus();
        }
        return isSuccess;
    }

    function forEachObject(obj, fn) {
        for (var property in obj) {
            if (obj.hasOwnProperty(property)) {
                //calls the fn with key and value as its argument
                fn(property, obj[property])
            }
        }
    }

    function getItem(keyName) {
        if (window.localStorage) {
            return window.localStorage.getItem(keyName);
        }
    }

    function isWeiXin() {
        return window.navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1;
    }

    function setItem(keyName, keyValue) {
        if (window.localStorage) {
            window.localStorage.setItem(keyName, keyValue);
        }
    }

    function times(times, fn) {
        for (var i = 0; i < times; i++) fn(i);
    }

    function toast(message, callback) {
        var container = document.createElement('div');
        container.setAttribute('id', 'toast');
        container.setAttribute('style', '-webkit-overflow-scrolling: touch;transition: background-color .1s;overflow-x: hidden;padding: .625em;justify-content: center;flex-direction: row;left: 0;bottom: 0;right: 0;top: 0;z-index: 1060;position: fixed;display: flex;-webkit-tap-highlight-color: transparent;align-items: center;background-color: rgba(0,0,0,.4);overflow-y: auto;')
        var popup = document.createElement('div');
        popup.setAttribute('style', 'font-size: 1rem;font-family: inherit;background: #fff;border-radius: .3125em;border: none;padding: 1.25em;max-width: 100%;width: 32em;justify-content: center;flex-direction: column;box-sizing: border-box;position: relative;-webkit-tap-highlight-color: transparent;animation: swal2-show .3s;-webkit-animation: swal2-show .3s;margin: auto;')
        container.appendChild(popup);
        var header = document.createElement('div');
        header.setAttribute('style', 'align-items: center;flex-direction: column;display: flex;-webkit-tap-highlight-color: transparent;');
        popup.appendChild(header);
        var title = document.createElement('h2');
        title.setAttribute('style', 'word-wrap: break-word;text-transform: none;text-align: center;font-weight: 600;font-size: 1.875em;color: #595959;padding: 0;margin: 0 0 .4em;max-width: 100%;position: relative;-webkit-tap-highlight-color: transparent;display: flex;');
        title.innerText = "信息";
        header.appendChild(title);
        var content = document.createElement('div');
        content.setAttribute('style', 'word-wrap: break-word;text-align: center;line-height: normal;font-weight: 400;font-size: 1.125em;color: #545454;padding: 0;margin: 0;justify-content: center;z-index: 1;-webkit-tap-highlight-color: transparent;');
        content.innerText = message;
        popup.appendChild(content);
        var actions = document.createElement('div');
        actions.setAttribute('style', 'margin: 1.25em auto 0;width: 100%;justify-content: center;align-items: center;flex-wrap: wrap;z-index: 1;display: flex;-webkit-tap-highlight-color: transparent;');
        popup.appendChild(actions);
        var okButton = document.createElement('button');
        okButton.setAttribute('style', 'border: 0;border-radius: .25em;background: initial;background-color: #3085d6;color: #fff;font-size: 1.0625em;font-weight: 500;box-shadow: none;padding: .625em 2em;margin: .3125em;background-image: linear-gradient(rgba(0,0,0,.2),rgba(0,0,0,.2));display: inline-block;border-left-color: rgb(48,133,214);border-right-color: rgb(48,133,214);');
        okButton.innerText = "确定";
        actions.appendChild(okButton);
        okButton.onclick = function () {
            document.body.removeChild(container);
            callback && callback();
        };
        document.body.appendChild(container);
    }

    function unless(predicate, fn) {
        if (!predicate)
            fn()
    }

    function e(message) {
        console.log("%cE, %s", 'color: Red', message)
    }


    window['__'] = {
        click: click,
        clipboard: clipboard,
        forEachObject: forEachObject,
        getItem: getItem,
        isWeiXin: isWeiXin,
        setItem: setItem,
        times: times,
        e: e,
        toast: toast,
        unless: unless,
    }
})();

