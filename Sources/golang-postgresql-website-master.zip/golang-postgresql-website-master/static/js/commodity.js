;(function () {

    var slider = document.getElementById('slider');
    if (!slider) return;

    function slide() {

        var dots = document.querySelectorAll('.bar li');

        // https://github.com/thebird/Swipe
        new Swipe(slider, {
            speed: 400,
            auto: 3000,
            callback: function (index, elem) {
                if (dots.length) {
                    for (var i = 0; i < dots.length; i++) {
                        var no = dots[i].getAttribute('no');
                        if (no === (index + '')) {
                            dots[i].setAttribute('class', 'cur');
                        } else {
                            dots[i].removeAttribute('class');
                        }
                    }
                }
            }
        });
    }

    function tables() {
        var tabs = document.querySelectorAll('.mod_tab .item');
        var tabItems = document.querySelectorAll('.detail_info_wrap>div');
        for (var i = 0; i < tabs.length; i++) {
            var cur = tabs[i];
            cur.addEventListener('click', function (event) {
                var id = event.target.getAttribute('data-target');

                for (var j = 0; j < tabs.length; j++) {
                    if (tabs[j] !== event.target) {
                        tabs[j].classList.remove('cur');
                    } else {
                        event.target.classList.add('cur');
                    }
                    if (id !== tabItems[j].getAttribute("id")) {
                        tabItems[j].style.display = 'none';
                    } else {
                        tabItems[j].style.display = 'block';
                    }
                }
            });
        }
    }

    function taobao() {
        __.click('#taobao_btn', function (e) {
            var uri = e.currentTarget.getAttribute('data-target') || "https://item.taobao.com/item.htm?id=606856824124";
            if (!__.isWeiXin()) {
                window.location = uri;
            } else {
                __.clipboard(uri);
                __.toast("已复制到剪切板。\n请用手机自带浏览器打开。");
            }

        });
    }

    function buy() {
        var buyBtn = document.getElementById('buy_btn');
        __.click('#buy_btn', function (event) {
            window.location = "./order?uid=" +
                buyBtn.getAttribute("data-target");
        });
    }

    function adjustImages() {
        var elements = document.querySelectorAll("#details img");
        var width = "width:" + window.innerWidth + "px";
        for (var i = 0, j = elements.length; i < j; i++) {
            elements[i].setAttribute('style', width);
        }
    }

    function goBack() {

        var element = document.querySelector('.m_header_bar_back');
        element.addEventListener('click', function () {
            if (!window.history.state)
                window.location = "./";
            else
                window.history.back();
        })
        document.addEventListener("backbutton", function () {
            if (!window.history.state)
                window.location = "./";
            else
                window.history.back();
        }, false);
    }

    function autoHeader() {
        var header = document.querySelector('.header_content');
        if (!header) return;
        var height = header.getClientRects()[0].height;
        var offset = document.getElementById('slider').getClientRects()[0].height >> 1;

        header.style.transform = 'translate3d(0px,-' + height + 'px,0px)';
        window.addEventListener('scroll', function () {
            if (window.scrollY >= offset) {
                header.style.transform = 'translate3d(0px,0px,0px)';
            } else {
                header.style.transform = 'translate3d(0px,-' + height + 'px,0px)';

            }

        })
    }

    function app() {
        slide();
        tables();
        goBack();
        taobao();
        buy();
        adjustImages();
        autoHeader();
        lazyload();
    }

    app();


})();