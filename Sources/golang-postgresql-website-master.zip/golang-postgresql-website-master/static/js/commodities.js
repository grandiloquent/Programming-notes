;(function () {

    var searchInput = document.getElementById('searchInput');
    if (!searchInput) return;

    // ==============================================

    var searchClose = document.querySelector('.search_close');
    var buyItems = document.querySelectorAll('.list_item_buy');

    // ==============================================
    var _filterType = 1;
    var _headerMenu;
    // ==============================================


    // -----------------------------------

    function headerMenu() {
        if (!_headerMenu) _headerMenu = document.querySelector('.header_menu');

    }

    // -----------------------------------
    // 清空搜索输入框
    function close(a, b) {
        var searchBox = document.querySelector('.search_box');
        var searchBtn = document.querySelector('.search_btn');

        a.addEventListener('input', function () {
            if (a.value.length)
                b.classList.remove('hide');
            else
                b.classList.add('hide');
        });
        a.addEventListener('click', showSearch);
        b.addEventListener('click', function () {
            a.value = '';
            b.classList.add('hide');
        });

        var listItems = document.getElementById('listItems');
        var searchResults = document.querySelector('.search_results');
        var filterWrap = document.querySelector('.filter_wrap');

        function showSearch() {
            listItems.classList.add('hide');
            searchResults.classList.remove('hide');
            filterWrap.classList.add('hide');
            searchBox.removeAttribute('style');
            searchBtn.classList.remove('hide');
            _headerMenu.classList.add('hide');
        }

        var goBack = document.querySelector('.m_header_bar_back');
        goBack.addEventListener('click', function () {
            listItems.classList.remove('hide');
            searchResults.classList.add('hide');
            filterWrap.classList.remove('hide');
            searchBtn.classList.add('hide');
            searchBox.setAttribute('style', 'margin-right: 32px');
            _headerMenu.classList.remove('hide');

        });

    }

    // -----------------------------------
    // 从服务器加载数据
    function loadingServer(filterType) {
        var container = document.getElementById('listItems');
        var length = container.childNodes.length;
        for (var i = 0; i < length; i++) {
            var element = container.childNodes[i];
            if (element && element.nodeType === 1)
                container.removeChild(element);
        }

        fetch('/commodities/api/filter?type=' + filterType).then(function (response) {
            return response.json();
        }).then(function (obj) {
            var array = [];
            for (var i = 0; i < obj.length; i++) {
                var uid = obj[i]['uid'];
                var title = obj[i]['title'];
                var price = obj[i]['price'];
                var thumbnail = obj[i]['thumbnail'];


                var format = "<a class=\"list_item\" href=\"/commodities/" + uid + "\" data-product-id=\"" + uid + "\"><div class=\"list_item_inner\"><div class=\"list_item_cover\"><img src=\"/commodities/static/images/" + thumbnail + "\"/></div><div class=\"list_item_info\"><div class=\"list_item_title\">" + title + "</div><div class=\"list_item_price\">" + price + "</div><div class=\"list_item_buy\"></div></div></div></a>";
                array.push(format)
            }
            container.innerHTML = array.join('');
        }).catch(function (err) {
            __.toast("发生未知错误。请稍后再试。");
        });

    }

    function filter() {
        var elements = document.querySelectorAll('.filter_items>a');
        for (var i = 0; i < elements.length; i++) {
            elements[i].addEventListener('click', function (event) {
                var element = event.target;
                if (element.classList.contains('cur'))
                    return;
                element.classList.add('cur');
                for (var j = 0; j < elements.length; j++) {
                    if (elements[j] === element) continue;
                    elements[j].classList.remove('cur');
                }
                var filterType = 1;
                var att = element.getAttribute('data-type');
                if (att === 'price')
                    filterType = 1;
                else if (att === 'sales') filterType = 2;
                else if (att === 'review') filterType = 3;

                _filterType = filterType;
                loadingServer(filterType);
            });
        }
    }

    // -----------------------------------
    // 购物车

    function buys(a) {


        for (var i = 0; i < a.length; i++) {
            a[i].addEventListener('click', function (e) {
                e.preventDefault();
                /*
                Identifies the current target for the event,
                as the event traverses the DOM.
                It always refers to the element to which
                the event handler has been attached,
                as opposed to event.target which identifies
                the element on which the event occurred.
                */
                var element = e.currentTarget;
                var uid = element.getAttribute('data-product-id');
                var cartString = __.getItem('cart');
                var cart = cartString ? JSON.parse(cartString) : {};

                if (cart[uid]) {
                    cart[uid] = cart[uid] + 1;
                } else {
                    cart[uid] = 1;
                }
                __.setItem('cart', JSON.stringify(cart));

                __.toast("已成功添加到购物车");
            });
        }
    }

    // -----------------------------------
    // 绑定滚动到底部时触发的事件
    function scrolling() {
        var isLoading = false;
        var factor = 1;
        var disable = false;


        window.addEventListener('scroll', function () {
            // console.log(
            //     "window.innerHeight = " + window.innerHeight + "\n",
            //     "window.outerHeight = " + window.outerHeight + "\n",
            //     "window.scrollY = " + window.scrollY + "\n",
            //     "window.pageYOffset = " + window.pageYOffset + "\n",
            //     "document.body.offsetTop = " + document.body.offsetTop + "\n",
            //     "document.body.clientHeight = " + document.body.clientHeight + "\n",
            //     "document.body.scrollHeight = " + document.body.scrollHeight + "\n",
            //     "document.body.offsetHeight = " + document.body.offsetHeight + "\n",
            // );
            var api = '/commodities/api/results';

            function loading() {
                if (disable) {

                    return;
                }
                if (isLoading) return;
                isLoading = true;
                fetch(api + '?factor=' + (factor++) + '&type=' + _filterType).then(onResponse).then(onResolved).catch(onRejected);
            }

            function onResponse(response) {
                isLoading = false;
                return response.json();
            }

            function onResolved(json) {
                if (!json)
                    throw new Error();
            }

            function onRejected() {
                disable = true;
                __.e("on rejected.")
            }


            if (window.scrollY + window.innerHeight >= document.body.offsetHeight) {
                loading();
            }
        });
    }


    // ==============================================
    headerMenu();
    close(searchInput, searchClose);
    buys(buyItems);
    filter();
    scrolling();
    lazyload();
})();