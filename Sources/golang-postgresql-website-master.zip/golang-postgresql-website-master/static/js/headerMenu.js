;(function () {
    var _headerMenu;

    function headerMenu() {
        if (!_headerMenu) _headerMenu = document.querySelector('.header_menu');
        if (!_headerMenu) return;
        var headerMenuContext = document.querySelector('.header_menu_context');
        _headerMenu.addEventListener('click', function (e) {
            e.stopPropagation();
            headerMenuContext.classList.toggle('hide');

        });


        window.addEventListener('scroll', function () {
            headerMenuContext.classList.contains('hide') || headerMenuContext.classList.add('hide');
        });
        document.addEventListener('click', function () {
            headerMenuContext.classList.add('hide');
        });
    }

    headerMenu();

})();