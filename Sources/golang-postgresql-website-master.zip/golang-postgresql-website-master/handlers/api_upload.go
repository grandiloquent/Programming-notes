package handlers

import (
	"commodities/common"
	"fmt"
	"io"
	"net/http"
	"os"
)

func ApiUploadHandler(e *common.Env) http.Handler {

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {

		if !checkAuthorization(r, e.AccessToken) {
			forbidden(w)
			return
		}

		in, header, err := r.FormFile("file")
		if err != nil {
			internalServerError(w, err)
			return
		}
		defer in.Close()

		// contentType := header.Header.Get("Content-Type")

		// if !strings.HasPrefix(contentType, "image/") {
		// 	badRequest(w)
		// 	return
		// }

		dstFileName := "static/images/" + header.Filename

		//if !utils.FileSystemExists(dstFileName) {

		// os/file.go
		outFile, err := os.Create(dstFileName)
		if err != nil {
			internalServerError(w, err)
			return
		}
		defer outFile.Close()
		_, err = io.Copy(outFile, in)
		if err != nil {
			internalServerError(w, err)
			return
		}
		//}
		w.WriteHeader(200)
		w.Write([]byte(fmt.Sprintf("%s", dstFileName)))

	})
}
