package handlers

import (
	"commodities/common"
	"commodities/dateparse"
	"encoding/json"
	"fmt"
	"github.com/gorilla/mux"
	"github.com/jackc/pgx/pgtype"
	"github.com/pkg/errors"
	"html/template"
	"net/http"
	"strconv"
	"time"
)

func formatPrices(i *pgtype.Numeric) string {
	fs, err := i.Value()
	if err != nil {
		return "0.00"
	}
	f, err := strconv.ParseFloat(fs.(string), 64)
	if err != nil {
		return "0.00"
	}
	return fmt.Sprintf("%.2f", common.ToFixed(f, 2))
}
func ApiExpenditureHandler(e *common.Env) http.Handler {

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {

		rows, err := e.DB.Query("select * from expenditures order by id")
		if err != nil {
			internalServerError(w, err)
			return
		}
		var items []interface{}
		for rows.Next() {
			row, err := rows.Values()
			if err != nil {
				internalServerError(w, err)
				return
			}
			//f, _ := row[2].(*pgtype.Numeric).Value()
			//fs := f.(string)
			//fv, _ := strconv.ParseFloat(fs, 64)
			//fmt.Println(fmt.Sprintf("-------------- %.2f", common.ToFixed(fv, 2)))
			//
			row[2] = formatPrices(row[2].(*pgtype.Numeric))
			row[5] = formatPrices(row[5].(*pgtype.Numeric))
			t := row[9].(time.Time)

			row[9] = fmt.Sprintf("%d-%02d-%02d %02d:%02d:%02d",
				t.Year(), t.Month(), t.Day(),
				t.Hour(), t.Minute(), t.Second())
			items = append(items, row)
		}
		t, err := template.ParseFiles("./templates/psycho/index.html")

		if err != nil {
			internalServerError(w, err)
			return
		}
		data := make(map[string]interface{})
		data["Items"] = items
		t.Execute(w, data)
	})
}


func ApiExpenditureAddHandler(e *common.Env) http.Handler {

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {

		var items interface{}
		err := readJson(r, &items)
		if err != nil {
			internalServerError(w, err)
			return
		}
		m, ok := items.(map[string]interface{})
		if !ok {
			internalServerError(w, errors.New("Parse error."))
			return
		}

		token, ok := m["token"].(string)
		if !ok || token != "psychochou" {
			forbidden(w)
			return
		}

		// -----------------------------------

		name := m["name"]
		price, ok := m["price"].(float64)
		if !ok {
			internalServerError(w, errors.New("Parse error."))
			return
		}
		quantity, ok := m["quantity"].(float64)
		if !ok {
			internalServerError(w, errors.New("Parse [ quantity ] error."))
			return
		}
		orderNo := m["order_no"]
		freight, ok := m["freight"].(float64)
		if !ok {
			internalServerError(w, errors.New("Parse error."))
			return
		}
		wholesaler, ok := m["wholesaler"].(string)
		if !ok {
			internalServerError(w, errors.New("Parse [ wholesaler ] error."))
			return
		}
		taobao := m["taobao"]
		taohuo := m["taohuo"]

		transactionDatetime, ok := m["transaction_datetime"].(string)
		if !ok {
			internalServerError(w, errors.New("Parse error."))
			return
		}
		td, err := dateparse.ParseAny(transactionDatetime)
		if err != nil {
			internalServerError(w, err)
			return
		}
		// -----------------------------------

		t, err := e.DB.Exec(`
		insert into expenditures(name,
		                        price,
		                        quantity,
		                        order_no,
		                        freight,
		                        wholesaler,
		                        taobao,
		                        taohuo,
		                        transaction_datetime)
		values ($1, $2, $3, $4, $5, $6, $7,$8,$9);`, name,
			price,
			int64(quantity),
			orderNo,
			freight,
			common.SubstringBeforeLast(wholesaler, '?'),
			taobao,
			taohuo,
			td)
		fmt.Println(t, err)

	})
}

func ApiExpenditureUpdateHandler(e *common.Env) http.Handler {

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {

		var items interface{}
		err := readJson(r, &items)
		if err != nil {
			internalServerError(w, err)
			return
		}
		m, ok := items.(map[string]interface{})
		if !ok {
			internalServerError(w, errors.New("Parse error."))
			return
		}

		token, ok := m["token"].(string)
		if !ok || token != "psychochou" {
			forbidden(w)
			return
		}

		// -----------------------------------
		id := m["id"]
		name := m["name"]
		price, ok := m["price"].(float64)
		if !ok {
			internalServerError(w, errors.New("Parse error."))
			return
		}
		quantity, ok := m["quantity"].(float64)
		if !ok {
			internalServerError(w, errors.New("Parse [ quantity ] error."))
			return
		}
		orderNo := m["order_no"]
		freight, ok := m["freight"].(float64)
		if !ok {
			internalServerError(w, errors.New("Parse error."))
			return
		}
		wholesaler, ok := m["wholesaler"].(string)
		if !ok {
			internalServerError(w, errors.New("Parse [ wholesaler ] error."))
			return
		}
		taobao := m["taobao"]
		taohuo := m["taohuo"]

		transactionDatetime, ok := m["transaction_datetime"].(string)
		if !ok {
			internalServerError(w, errors.New("Parse error."))
			return
		}
		td, err := dateparse.ParseAny(transactionDatetime)
		if err != nil {
			internalServerError(w, err)
			return
		}
		// -----------------------------------

		t, err := e.DB.Exec(`
		update expenditures set 
name = $1,
price = $2,
quantity = $3,
order_no = $4,
freight = $5,
wholesaler = $6,
taobao = $7,
taohuo = $8,
transaction_datetime = $9 where id=$10`, name,
			price,
			int64(quantity),
			orderNo,
			freight,
			common.SubstringBeforeLast(wholesaler, '?'),
			taobao,
			taohuo,
			td, id)
		fmt.Println(t, err)

	})
}

func ApiExpenditureFetchHandler(e *common.Env) http.Handler {

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		idStr := mux.Vars(r)["id"]
		id, err := strconv.Atoi(idStr)
		if err != nil {
			internalServerError(w, err)
			return
		}
		var name string
		var price pgtype.Numeric
		var quantity int64
		var order_no string
		var freight pgtype.Numeric
		var wholesaler string
		var taobao string
		var taohuo string
		var t time.Time

		err = e.DB.QueryRow(`select
name ,
price ,
quantity ,
order_no ,
freight ,
wholesaler ,
taobao ,
taohuo ,
transaction_datetime 
 from expenditures where id=$1`, id).Scan(
			&name,
			&price,
			&quantity,
			&order_no,
			&freight,
			&wholesaler,
			&taobao,
			&taohuo,
			&t,
		)
		if err != nil {
			internalServerError(w, err)
			return
		}
		m := make(map[string]interface{})
		m["id"] = id
		m["name"] = name
		m["price"] = formatPrices(&price)
		m["quantity"] = quantity
		m["order_no"] = order_no
		m["freight"] = formatPrices(&freight)
		m["wholesaler"] = wholesaler
		m["taobao"] = taobao
		m["taohuo"] = taohuo
		m["transaction_datetime"] = fmt.Sprintf("%d-%02d-%02d %02d:%02d:%02d",
			t.Year(), t.Month(), t.Day(),
			t.Hour(), t.Minute(), t.Second())

		buf, err := json.Marshal(m)
		if err != nil {
			internalServerError(w, err)
			return
		}
		w.Write(buf)
	})
}

func ApiExpenditureOrderNoHandler(e *common.Env) http.Handler {

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		orderno := mux.Vars(r)["orderno"]
		rows, err := e.DB.Query(`select price,freight,quantity  from expenditures where order_no=$1`, orderno)

		if err != nil {
			internalServerError(w, err)
			return
		}

		var items []interface{}

		for rows.Next() {
			row, err := rows.Values()
			if err != nil {
				internalServerError(w, err)
				return
			}
			fs, err := row[0].(*pgtype.Numeric).Value()
			if err != nil {
				internalServerError(w, err)
				return
			}
			f, err := strconv.ParseFloat(fs.(string), 64)
			row[0] = f

			fs, err = row[1].(*pgtype.Numeric).Value()
			if err != nil {
				internalServerError(w, err)
				return
			}
			f, err = strconv.ParseFloat(fs.(string), 64)
			row[1] = f
			items = append(items, row)
		}
		var total float64

		for _, f := range items {
			a := f.([]interface{})
			total += a[0].(float64) * float64(a[2].(int32))
		}
		freight := items[0].([]interface{})[1]

		w.Write([]byte(fmt.Sprintf("%.2f", total+freight.(float64))))

	})
}
