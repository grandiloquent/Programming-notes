package handlers

import (
	"commodities/common"
	"encoding/json"
	"net/http"
)

const (
	InertOrdersSQL = "insert into orders (uid,username,phone,address) values($1,$2,$3,$4)"
)

func ApiOrderHandler(e *common.Env) http.Handler {

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var items interface{};
		err := readJson(r, &items);
		if err != nil {
			internalServerError(w, err)
		}
		itemsArray := items.([]interface{})

		t, err := e.DB.Exec(InertOrdersSQL, itemsArray...)
		if err != nil {
			internalServerError(w, err)
			return
		}
		m := make(map[string]interface{})
		m["sucess"] = true
		m["rowsAffected"] = t.RowsAffected()
		b, err := json.Marshal(m)
		if err != nil {
			internalServerError(w, err)
		}
		w.Write(b)
	})
}
