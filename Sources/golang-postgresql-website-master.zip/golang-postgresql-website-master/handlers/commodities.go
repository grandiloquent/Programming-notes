package handlers

import (
	"commodities/common"
	"github.com/jackc/pgx/pgtype"
	"html/template"
	"log"
	"net/http"
	"strconv"
)

const (
	ListQuerySQL = "select * from commodity_list($1,$2)"
)

func CommoditiesHandler(e *common.Env) http.Handler {

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {

		rows, err := e.DB.Query(ListQuerySQL, 20, 0);
		if err != nil {
			internalServerError(w, err)
			return
		}
		var items []interface{}

		for rows.Next() {
			row, err := rows.Values()
			if err != nil {
				log.Println(err)
				continue
			}
			n, ok := row[2].(*pgtype.Numeric);
			if ok {
				v, err := n.Value()
				if err != nil {
					log.Println(err)
					continue
				}
				f, err := strconv.ParseFloat(v.(string), 64)
				if err != nil {
					log.Println(err)
					continue
				}
				row[2] = template.HTML(formatPrice(f))
			}

			items = append(items, row)
		}
		m := make(map[string]interface{})
		m["PageTitle"] = "热门商品"
		m["Commodities"] = items
		m["Debug"] = e.Debug

		renderTemplate(w, "./templates/commodities.html", m)
	})
}
