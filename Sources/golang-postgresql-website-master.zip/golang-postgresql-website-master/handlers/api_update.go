package handlers

import (
	"commodities/common"
	"fmt"
	"net/http"
)

const (
	UpdateCommoditySQL = "select * from commodity_update($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)"
)

func ApiUpdateHandler(e *common.Env) http.Handler {

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !checkAuthorization(r, e.AccessToken) {
			forbidden(w)
			return
		}
		// ===============================================================
		// 读取 JSON
		var items interface{}
		err := readJson(r, &items)
		if err != nil {
			internalServerError(w, err)
			return
		}

		// ===============================================================
		// 读取具体数据

		m := items.(map[string]interface{})

		// -----------------------------------
		// 价格必须是合法数据
		price, err := toFloat(m["price"])
		title := m["title"]

		// -----------------------------------

		uid := m["uid"]
		thumbnail := m["thumbnail"]
		details := m["details"]
		specification := m["specification"]
		service := m["service"]
		properties := joinArray(m["properties"])
		showcases := joinArray(m["showcases"])
		taobao := m["taobao"]
		wholesale := m["wholesale"]
		// ===============================================================
		// SQL 语句

		//sql := fmt.Sprintf("select * from commodity_insert('%s',%f,'%s','%s','%s','%s','%s')\n", title,
		//	price,
		//	details,
		//	specification,
		//	service,
		//	properties,
		//	showcases)
		//fmt.Println(sql)

		// ===============================================================
		// 插入数据库
		t, err := e.DB.Exec(UpdateCommoditySQL, uid,
			title,
			price,
			thumbnail,
			details,
			taobao,
			wholesale,
			specification,
			service,
			properties,
			showcases,
		)

		if err != nil {
			internalServerError(w, err)
			return
		}

		//fmt.Println(uid)
		// ===============================================================
		// 返回新创建项的ID

		_, _ = w.Write([]byte(fmt.Sprintf("%d", t.RowsAffected())))
	})
}
