package handlers

import (
	"commodities/common"
	"commodities/pudge"
	"net/http"
)

const (
	PudgeFileName = "./Storage"

	KeyTransaction = "transaction"
)

func transactionGet(w http.ResponseWriter) {
	var output string
	err := pudge.Get(PudgeFileName, KeyTransaction, &output)
	if err != nil {
		internalServerError(w, err)
		return
	}
}
func transactionPost(e *common.Env, w http.ResponseWriter, r *http.Request) {
	if !checkAuthorization(r, e.AccessToken) {
		forbidden(w)
		return
	}
	// ===============================================================
	// 读取 JSON
	var items interface{}
	err := readJson(r, &items)
	if err != nil {
		internalServerError(w, err)
		return
	}

}
func ApiTransactionHandler(e *common.Env) http.Handler {

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.Method {
		case "GET":
			transactionGet(w)
			break
		case "POST":
			transactionPost(e, w, r)
			break
		}
	})
}
