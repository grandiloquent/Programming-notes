package handlers

import (
	"commodities/common"
	"net/http"
)

func OrderHandler(e *common.Env) http.Handler {

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {

		// ===============================================================
		// 初始化模板数据

		data := make(map[string]interface{})
		data["PageTitle"] = "提交订单"
		data["Debug"] = e.Debug

		renderTemplate(w, "./templates/order.html", data)
	})
}
