package handlers

import (
	"commodities/blackfriday"
	"commodities/common"
	"fmt"
	"github.com/gorilla/mux"
	_ "github.com/gorilla/mux"
	"github.com/jackc/pgx/pgtype"
	"html/template"
	"log"
	"net/http"
)

type Commodity struct {
	Uid           string
	Title         string
	Price         template.HTML
	Showcases     []string
	Taobao        template.URL
	Specification template.HTML
	Service       template.HTML
	Details       template.HTML
}

const (
	QuerySQLCommodity = "select title,price,details,specification,service,taobao,properties,showcases from commodities where uid=$1"
)

func CommodityHandler(e *common.Env) http.Handler {

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {

		vars := mux.Vars(r)
		uid := vars["uid"]

		// ===============================================================
		// 从数据库读取数据
		var title string
		var price float64
		var details string
		var specification string
		var service string
		var properties []string
		var showcases []string
		var taobao pgtype.Text

		err := e.DB.QueryRow(QuerySQLCommodity, uid).Scan(
			&title,
			&price,
			&details,
			&specification,
			&service,
			&taobao,
			&properties,
			&showcases)
		if err != nil {
			log.Println("CommodityHandler: ", err)
		}

		// ===============================================================
		// 初始化模型

		commodity := Commodity{
			Uid:           uid,
			Title:         title,
			Price:         template.HTML(formatPrice(price)),
			Showcases:     showcases,
			Taobao:        template.URL(taobao.String),
			Specification: template.HTML(blackfriday.Run([]byte(specification))),
			Service:       template.HTML(blackfriday.Run([]byte(service))),
			Details:       template.HTML(blackfriday.Run([]byte(details))),
		}
		fmt.Println(commodity.Showcases)

		// ===============================================================
		// 初始化模板数据

		data := make(map[string]interface{})
		data["PageTitle"] = title
		data["Commodity"] = commodity
		data["Debug"] = e.Debug
		renderTemplate(w, "./templates/commodity.html", data)
	})
}
