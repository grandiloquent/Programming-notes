package handlers

import "testing"

func TestFormatPrice(t *testing.T) {

	if formatPrice(0) != "¥<em>0</em>.00" {
		t.Errorf("TestFormatPrice: %s \n", formatPrice(0))
	}
}
