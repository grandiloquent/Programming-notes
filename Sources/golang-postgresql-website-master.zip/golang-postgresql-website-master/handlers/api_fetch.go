package handlers

import (
	"commodities/common"
	"encoding/json"
	"fmt"
	"github.com/jackc/pgx/pgtype"
	"net/http"
)

const (
	FetchCommoditySQL = "select title,price,thumbnail,details,specification,service,taobao,wholesale,properties,showcases from commodities where uid = $1"
)

func ApiFetchHandler(e *common.Env) http.Handler {

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {

		if !checkAuthorization(r, e.AccessToken) {
			forbidden(w)
			return
		}

		uid := r.URL.Query().Get("uid")
		fmt.Println(uid)
		buf, err := FetchCommodity(uid, e)
		if err != nil {
			internalServerError(w, err)
			return
		}
		w.Write(buf)

	})
}

func FetchCommodity(uid string, e *common.Env) ([]byte, error) {

	var (
		title         string
		price         float64
		thumbnail     string
		details       string
		specification string
		service       string
		properties    pgtype.TextArray
		showcases     pgtype.TextArray
		taobao        pgtype.Text
		wholesale     pgtype.Text
	)

	err := e.DB.QueryRow(FetchCommoditySQL, uid).Scan(
		&title,
		&price,
		&thumbnail,
		&details,
		&specification,
		&service,
		&taobao,
		&wholesale,
		&properties,
		&showcases,

	)
	if err != nil {
		return nil, err
	}
	m := make(map[string]interface{})

	m["uid"] = uid
	m["title"] = title
	m["price"] = common.ToFixed(price, 2)
	m["thumbnail"] = thumbnail
	m["details"] = details
	m["specification"] = specification
	m["service"] = service
	m["properties"] = properties.Elements
	m["showcases"] = showcases.Elements
	m["taobao"] = taobao.String
	m["wholesale"] = wholesale.String

	buf, err := json.Marshal(m)
	if err != nil {
		return nil, err
	}
	return buf, nil
}
