package handlers

import (
	"commodities/common"
	"net/http"
)

func ApiResultsHandler(e *common.Env) http.Handler {

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fetchResults(e, w, r)
	})
}
