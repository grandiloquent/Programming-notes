package handlers

import (
	"commodities/common"
	"encoding/json"
	"github.com/jackc/pgx/pgtype"
	"net/http"
	"strconv"
)

func ApiFilterHandler(e *common.Env) http.Handler {

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fetchResults(e, w, r)
	})
}

func fetchResults(e *common.Env, w http.ResponseWriter, r *http.Request) {
	factor := r.URL.Query().Get("factor")
	filterType := r.URL.Query().Get("type")
	t, err := strconv.Atoi(filterType)
	if err != nil || t < 1 || t > 3 {
		badRequest(w)
		return
	}
	f, err := strconv.Atoi(factor)
	if err != nil {
		f = 0
	}
	rows, err := e.DB.Query("select * from commodity_filter($1,$2,$3)", t, 20, 20*f)
	if err != nil {
		internalServerError(w, err)
		return
	}
	var items []map[string]interface{}
	for rows.Next() {
		row, err := rows.Values();
		if err != nil {
			internalServerError(w, err)
			return
		}
		m := make(map[string]interface{})
		m["uid"] = row[0]
		m["title"] = row[1]
		var v float64
		row[2].(*pgtype.Numeric).AssignTo(&v)

		m["price"] = common.ToFixed(v, 2)
		m["thumbnail"] = row[3]

		items = append(items, m)
	}
	b, err := json.Marshal(items);
	if err != nil {
		internalServerError(w, err)
		return
	}
	w.Write(b)
}
