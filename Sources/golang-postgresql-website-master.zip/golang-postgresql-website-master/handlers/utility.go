package handlers

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"fmt"
	"github.com/pkg/errors"
	"html/template"
	"io"
	"log"
	"net/http"
	"strings"
	"unicode"
)

func renderTemplate(w http.ResponseWriter, templateFile string, templateData interface{}) {
	t, err := template.ParseFiles(templateFile, "./templates/header.html", "./templates/footer.html")
	if err != nil {
		log.Printf("Error encountered while parsing the template: ", err)
	}
	t.Execute(w, templateData)
}
func checkAuthorization(r *http.Request, accessToken string) bool {
	a := r.Header.Get("Authorization")
	b := "Bearer "
	if len(b)+len(accessToken) == len(a) && strings.HasPrefix(a, b) && strings.HasSuffix(a, accessToken) {
		return true
	}
	return false
}
func forbidden(w http.ResponseWriter) {
	http.Error(w, http.StatusText(http.StatusForbidden), http.StatusForbidden)
}
func notFound(w http.ResponseWriter) {
	http.Error(w, http.StatusText(http.StatusNotFound), http.StatusNotFound)
}
func badRequest(w http.ResponseWriter) {
	http.Error(w, http.StatusText(http.StatusBadRequest), http.StatusBadRequest)
}
func readJson(r *http.Request, items *interface{}) error {
	defer r.Body.Close()
	var err error
	var reader io.ReadCloser
	switch r.Header.Get("Content-Encoding") {
	case "gzip":
		reader, err = gzip.NewReader(r.Body)
		if err != nil {
			return err
		}
		defer reader.Close()
	default:
		reader = r.Body
	}
	decoder := json.NewDecoder(reader)
	return decoder.Decode(items)
}
func internalServerError(w http.ResponseWriter, err error) {
	log.Printf("error, %s", err.Error())
	http.Error(w, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
}
func toFloat(i interface{}) (float64, error) {
	f, ok := i.(float64)
	if ok {
		return f, nil;
	}
	return 0, errors.New("invalid")
}
func joinArray(i interface{}) string {
	if i == nil {
		return "{}"
	}
	a := i.([]interface{})
	if a == nil {
		return ""
	}

	var buf bytes.Buffer
	buf.WriteString("{")

	if len(a) > 0 {
		s, ok := a[0].(string)
		if ok {
			buf.WriteString(s)
		}
	}
	if len(a) > 1 {
		for _, v := range a[1:] {
			s, ok := v.(string)
			if ok {
				buf.WriteString(",")
				buf.WriteString(s)
			}
		}
	}
	buf.WriteString("}")
	return buf.String()
}
func isWhiteSpaceString(i interface{}) bool {
	s, ok := i.(string)
	if !ok {
		return false
	}

	for _, v := range s {
		if !    unicode.IsSpace(v) {
			return false
		}
	}
	return true
}
func formatPrice(price float64) string {

	p := fmt.Sprintf("%.2f", price)
	pieces := strings.Split(p, ".")
	start := pieces[0]
	end := "00"
	if len(pieces) > 1 {
		end = pieces[1]
	}

	return fmt.Sprintf("¥<em>%s</em>.%s", start, end)

}
func formatPriceString(price string) string {

	pieces := strings.Split(price, ".")
	start := pieces[0]
	end := "00"
	if len(pieces) > 1 {
		end = pieces[1]
	}

	return fmt.Sprintf("¥<em>%s</em>.%s", start, end)

}
