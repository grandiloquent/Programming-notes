package main

import (
	"./utils"
	"bytes"
	"fmt"
	"github.com/PuerkitoBio/goquery"
	"io"
	"log"
	"net/http"
	"os"
	"strings"
	"sync"
)

// go get -u github.com/PuerkitoBio/goquery

func downloadFile(uri, fileName string) error {
	file, err := os.Create(fileName)
	if err != nil {
		return err
	}
	defer file.Close()
	client := &http.Client{}
	req, err := http.NewRequest("GET", uri, nil)
	if err != nil {
		return err
	}
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	buf := make([]byte, 8192)
	var writeIndex int64 = 0
	for {
		n, err := resp.Body.Read(buf)
		if n > 0 {
			writeSize, err := file.WriteAt(buf[0:n], writeIndex)
			if err != nil {
				return err
			}
			writeIndex += int64(writeSize)
		}
		if err != nil {
			if err != io.EOF {
				return err
			}
			break
		}
	}
	return nil

}

func downloadFileAsync(wg *sync.WaitGroup, sema chan struct{}, uri, fileName string) error {
	sema <- struct{}{}
	defer func() {
		<-sema
		wg.Done()
	}()

	file, err := os.Create(fileName)
	if err != nil {
		return err
	}
	defer file.Close()
	client := &http.Client{}
	req, err := http.NewRequest("GET", uri, nil)
	if err != nil {
		return err
	}
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	buf := make([]byte, 8192)
	var writeIndex int64 = 0
	for {
		n, err := resp.Body.Read(buf)
		if n > 0 {
			writeSize, err := file.WriteAt(buf[0:n], writeIndex)
			if err != nil {
				return err
			}
			writeIndex += int64(writeSize)
		}
		if err != nil {
			if err != io.EOF {
				return err
			}
			break
		}
	}
	return nil

}
func main() {
	string, err := utils.ReadAll()
	if err != nil {
		log.Fatalln(err)
	}
	buf := bytes.NewBuffer(nil)
	buf.WriteString(string)

	doc, err := goquery.NewDocumentFromReader(buf)
	if err != nil {
		log.Fatalln(err)
	}
	var wg sync.WaitGroup
	// limit to four downloads at a time, this is called a semaphore
	limiter := make(chan struct{}, 4)

	doc.Find("img").Each(func(i int, s *goquery.Selection) {
		src, _ := s.Attr("src")
		if !strings.HasPrefix(src, "https:") {
			src = "https:" + src
		}
		wg.Add(1)
		go downloadFileAsync(&wg, limiter, src, utils.SubstringAfterLast(src, '/'))
		fmt.Println(src)
	})
	wg.Wait()

}
