package main

import (
	"bytes"
	"commodities/common"
	"commodities/common/datastore"
	"commodities/handlers"
	"commodities/middleware"
	"encoding/json"
	"fmt"
	ghandlers "github.com/gorilla/handlers"
	"github.com/gorilla/mux"
	"github.com/justinas/alice"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"os/exec"
	"regexp"
	"strings"
)

const (
	WEBSERVERPORT = ":5050"
	// 192.168.1.11
)

func renameFile(dir, prefix, suffix string, fn func(string)) {

	fs, err := ioutil.ReadDir(dir)
	if err != nil {
		log.Fatal(err)
	}
	for _, f := range fs {
		if !f.IsDir() && strings.HasPrefix(f.Name(), prefix) && strings.HasSuffix(f.Name(), suffix) {
			md5, err := common.FileMd5(dir + "/" + f.Name())
			if err != nil {
				log.Fatal(err)
			}
			n := fmt.Sprintf("%s_%s%s", common.SubstringBeforeLast(common.SubstringBefore(f.Name(), '_'), '.'), md5, suffix)
			if f.Name() != n {
				os.Rename(fmt.Sprintf("%s/%s", dir, f.Name()), fmt.Sprintf("%s/%s", dir, n))
			}
			fn(md5)
			break
		}
	}
}

func updateVersion(templateFileName, version, search, format string) {
	b, err := ioutil.ReadFile(templateFileName)
	if err != nil {
		log.Fatal(err)
	}

	r := regexp.MustCompile(search)
	b = r.ReplaceAll(b, []byte(fmt.Sprintf(format, version)))
	ioutil.WriteFile(templateFileName, b, 0644)
}

func main() {
	debug := false
	if len(os.Args) > 1 {
		for _, v := range os.Args[1:] {
			if v == "debug" {
				debug = true
			} else if v == "release" {
				mergeStyles()

				renameFile("static/css", "commodities", ".css", func(s string) {
					updateVersion("templates/header.html", s, "/static/css/commodities[_a-z0-9]*.css", "/static/css/commodities_%s.css")
				})
				mergeJavaScripts()
				renameFile("static/js", "app", ".js", func(s string) {
					updateVersion("templates/footer.html", s, "/static/js/app[_a-z0-9]*.js", "/static/js/app_%s.js")
				})
			}
		}
	}
	var config map[string]interface{}
	buf, err := ioutil.ReadFile("./configurations.json")
	if err != nil {
		log.Fatal(err)
	}
	err = json.Unmarshal(buf, &config)
	if err != nil {
		log.Fatal(err)
	}
	database := config["Database"].(map[string]interface{})
	host := ""
	if debug {
		host = database["Host"].(string)
	}

	db, err := datastore.NewDataStore(database["User"].(string), database["Password"].(string), database["Database"].(string), host)

	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()
	env := common.Env{DB: *db, Debug: debug}

	env.AccessToken = config["AccessToken"].(string)

	// ==============================================

	//handlers.FetchCommodity("xncqeq", &env)
	r := mux.NewRouter()

	// ---------------------------------------------------------------

	r.Handle("/", handlers.CommoditiesHandler(&env)).Methods("GET")
	r.Handle("/commodities", handlers.CommoditiesHandler(&env)).Methods("GET")
	r.Handle("/commodities/order", handlers.OrderHandler(&env)).Methods("GET")
	r.Handle("/commodities/{uid}", handlers.CommodityHandler(&env)).Methods("GET")

	// ---------------------------------------------------------------

	r.Handle("/commodities/api/commodity/insert", handlers.ApiInsertHandler(&env)).Methods("POST")
	r.Handle("/commodities/api/commodity/update", handlers.ApiUpdateHandler(&env)).Methods("POST")
	r.Handle("/commodities/api/commodity/upload", handlers.ApiUploadHandler(&env)).Methods("POST")

	r.Handle("/commodities/api/order", handlers.ApiOrderHandler(&env)).Methods("POST")
	r.Handle("/commodities/api/commodity/fetch", handlers.ApiFetchHandler(&env)).Methods("GET")
	r.Handle("/commodities/api/filter", handlers.ApiFilterHandler(&env)).Methods("GET")
	r.Handle("/commodities/api/results", handlers.ApiResultsHandler(&env)).Methods("GET")
	r.Handle("/commodities/api/transaction", handlers.ApiTransactionHandler(&env)).Methods("GET", "POST")

	// -----------------------------------
	r.Handle("/commodities/api/psycho/expenditure", handlers.ApiExpenditureHandler(&env)).Methods("GET")
	r.Handle("/commodities/api/psycho/expenditure/add", handlers.ApiExpenditureAddHandler(&env)).Methods("POST")
	r.Handle("/commodities/api/psycho/expenditure/fetch/{id}", handlers.ApiExpenditureFetchHandler(&env)).Methods("GET")
	r.Handle("/commodities/api/psycho/expenditure/update", handlers.ApiExpenditureUpdateHandler(&env)).Methods("POST")
	r.Handle("/commodities/api/psycho/expenditure/orderno/{orderno}", handlers.ApiExpenditureOrderNoHandler(&env)).Methods("GET")

	// ---------------------------------------------------------------

	loggedRouter := ghandlers.LoggingHandler(os.Stdout, r)
	//stdChain := alice.New(middleware.PanicRecoveryHandler)

	stdChain := alice.New(middleware.PanicRecoveryHandler, middleware.RemoveTrailingSlashHandler)
	http.Handle("/", stdChain.Then(loggedRouter))

	r.PathPrefix("/commodities/static/").Handler(http.StripPrefix("/commodities/static/", http.FileServer(http.Dir("./static"))))

	err = http.ListenAndServe(WEBSERVERPORT, nil)
	if err != nil {
		log.Fatal("ListenAndServe: ", err)
	}

}

func mergeStyles() {
	// ==============================================
	// 删除commodities开头的css文件

	fs, err := ioutil.ReadDir("static/css")
	if err != nil {
		log.Fatal(err)
	}
	for _, f := range fs {
		if !f.IsDir() && strings.HasPrefix(f.Name(), "commodities") && strings.HasSuffix(f.Name(), ".css") {

			os.Remove("static/css/" + f.Name())
		}
	}
	// ==============================================
	b, err := ioutil.ReadFile("templates/header.html")
	if err != nil {
		log.Fatal(err)
	}
	r := regexp.MustCompile("/commodities/static/css/(\\.[a-zA-Z0-9]+.css)")

	bb := r.FindAllSubmatch(b, -1)
	var bw bytes.Buffer
	for _, buf := range bb {
		fn := string(buf[1])
		f := "static/css/" + fn
		b, err = ioutil.ReadFile(f)
		if err != nil {
			log.Fatal(err)
		}
		bw.Write(b)
	}
	df := "static/css/commodities.css"
	ioutil.WriteFile(df, bw.Bytes(), 0644)

	runCommand("csso", df, "--output", df)

	// ==============================================
	// npm install -g csso-cli

}

func mergeJavaScripts() {
	fs, err := ioutil.ReadDir("static/js")
	if err != nil {
		log.Fatal(err)
	}
	for _, f := range fs {
		if !f.IsDir() && strings.HasPrefix(f.Name(), "app") && strings.HasSuffix(f.Name(), ".js") {

			os.Remove("static/js/" + f.Name())
		}
	}
	// ==============================================
	b, err := ioutil.ReadFile("templates/footer.html")
	if err != nil {
		log.Fatal(err)
	}
	r := regexp.MustCompile("/commodities/static/js/([a-zA-Z0-9]+.js)")

	bb := r.FindAllSubmatch(b, -1)
	var bw bytes.Buffer
	for _, buf := range bb {
		fn := string(buf[1])
		fmt.Println(fn)
		f := "static/js/" + fn
		b, err = ioutil.ReadFile(f)
		if err != nil {
			log.Fatal(err)
		}
		bw.Write(b)
	}
	df := "static/js/app.js"
	ioutil.WriteFile(df, bw.Bytes(), 0644)

	// ==============================================
	// npm install uglify-js -g
	// 压缩 JavaScript

	runCommand("uglifyjs", df, "-o", df)

}
func runCommand(name string, arg ...string) {

	cmd, err := exec.Command(name, arg...).CombinedOutput()
	if err != nil {
		fmt.Println(err)
	}
	fmt.Println(name, arg, string(cmd))
}
