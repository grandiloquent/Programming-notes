package common

import "commodities/common/datastore"

type Env struct {
	DB          datastore.DataStore
	AccessToken string
	Debug       bool
}
