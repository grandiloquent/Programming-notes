# Golang PostgreSQL Website exercise

[Live Demo](https://halalla.cn/commodities):https://halalla.cn/commodities

## Third-party libraries

- https://github.com/PacktPublishing/Back-End-Web-Development-using-Go

### GoLang

- https://github.com/gorilla/mux
- https://github.com/russross/blackfriday
- https://github.com/jackc/pgx
- https://github.com/justinas/alice
- https://github.com/recoilme/pudge

## JavaScript

- https://github.com/thebird/Swipe

## SQL

[SQL Script](./database.sql)
