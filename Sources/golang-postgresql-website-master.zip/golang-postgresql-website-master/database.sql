create table commodities
(
    "_id"         serial         not null
        constraint commodities_pk
            primary key,
    uid           text           not null,
    title         text           not null,
    price         numeric(15, 6) not null,
    thumbnail     text,
    details       text,
    specification text,
    service       text,
    properties    text[],
    showcases     text[],
    create_at     timestamp,
    update_at     timestamp
);

--
drop table expenditures;
create table expenditures
(
    "id"                 serial not null
        constraint expenditures_pk
            primary key,
    name                 text,
    price                numeric(15, 6),
    quantity             int,
    order_no             text,
    freight              numeric(15, 6),
    wholesaler           text,
    taobao               text,
    taohuo               text,
    transaction_datetime timestamp
);

insert into expenditures(name,
                         price,
                         quantity,
                         order_no,
                         freight,
                         wholesaler,
                         transaction_datetime)
values ($1, $2, $3, $4, $5, $6, $7);

-- 创建长度6的ID

create function make_commodities_uid() returns text
    language plpgsql
as
$$
declare
    new_uid text;
    done    bool;
begin
    done := false;
    while not done
        loop
            select string_agg(x, '')
            into new_uid
            from (
                     select chr(ascii('a') + floor(random() * 26)::integer)
                     from generate_series(1, 6)
                 ) as y(x);
            done := not exists(select 1 from commodities where uid = new_uid);
        end loop;
    return new_uid;
end;
$$;


create or replace function commodity_insert(title_val text,
                                            price_val numeric,
                                            thumbnail_val text,
                                            details_val text,
                                            specification_val text,
                                            service_val text,
                                            properties_val text[],
                                            showcases_val text[]) returns text
    language plpgsql
as
$$
declare
    uid_val text;
begin

    select uid from commodities where title = title_val into uid_val;
    if uid_val is not null
    then
        return uid_val;
    end if;
    insert into commodities(uid,
                            title,
                            price,
                            thumbnail,
                            details,
                            specification,
                            service,
                            properties,
                            showcases,
                            create_at,
                            update_at)
    values (make_commodities_uid(),
            title_val,
            price_val,
            thumbnail_val,
            details_val,
            specification_val,
            service_val,
            properties_val,
            showcases_val,
            now(),
            now()) returning uid into uid_val;
    return uid_val;
end;
$$;

drop function commodity_update(uid_val text,
    title_val text,
    price_val numeric,
    thumbnail_val text,
    details_val text,
    taobao_val text,
    specification_val text,
    service_val text,
    properties_val text[],
    showcases_val text[]);

CREATE OR REPLACE FUNCTION commodity_update(uid_val text,
                                            title_val text,
                                            price_val numeric,
                                            thumbnail_val text,
                                            details_val text,
                                            taobao_val text,
                                            wholesale_val text,
                                            specification_val text,
                                            service_val text,
                                            properties_val text[],
                                            showcases_val text[])
    RETURNS void
    LANGUAGE 'plpgsql'

    COST 100
    VOLATILE
AS
$BODY$
declare
    properties_array text[];
    showcases_array  text[];

begin

    if array_length(properties_val, 1) > 0 then
        properties_array = properties_val;
    end if;

    if array_length(showcases_val, 1) > 0 then
        showcases_array = showcases_val;
    end if;

    update
        commodities
    set title= COALESCE(title_val, title),
        price = COALESCE(price_val, price),
        thumbnail = COALESCE(thumbnail_val, thumbnail),
        taobao=COALESCE(taobao_val, taobao),
        wholesale=COALESCE(wholesale_val, wholesale),
        details = COALESCE(details_val, details),
        specification = COALESCE(specification_val, specification),
        service = COALESCE(service_val, service),
        properties = COALESCE(properties_array, properties),
        showcases = COALESCE(showcases_array, showcases),
        update_at = now()
    where uid = uid_val;
end;
$BODY$;

create or replace function commodity_list(limit_val int, offset_val int)
    returns table
            (
                uid       text,
                title     text,
                price     numeric(15, 6),
                thumbnail text
            )
    language plpgsql
as
$$
begin

    return query select commodities.uid, commodities.title, commodities.price, commodities.thumbnail
                 from commodities
                 order by update_at desc
                 limit limit_val
                     offset offset_val;
end;
$$;

--

alter table commodities
    rename to old_commodities;
alter index commodities_pk rename to old_commodities_pk;


create table commodities
(
    "_id"         serial         not null
        constraint commodities_pk
            primary key,
    uid           text           not null,
    title         text           not null,
    price         numeric(15, 6) not null,
    thumbnail     text,
    details       text,
    specification text,
    service       text,
    taobao        text,
    sales         integer,
    properties    text[],
    showcases     text[],
    create_at     timestamp,
    update_at     timestamp
);

insert into commodities (_id, uid,
                         title,
                         price,
                         thumbnail,
                         details,
                         specification,
                         service,
                         taobao,
                         sales,
                         properties,
                         showcases,
                         create_at,
                         update_at)
select _id,
       uid,
       title,
       price,
       thumbnail,
       details,
       specification,
       service,
       taobao,
       sales,
       properties,
       showcases,
       create_at,
       update_at
from old_commodities;

--

create or replace function commodity_filter(filter_type int, limit_val int, offset_val int)
    returns table
            (
                uid       text,
                title     text,
                price     numeric(15, 6),
                thumbnail text
            )
    language plpgsql
as
$$
begin
    if filter_type = 1 then
        return query select commodities.uid, commodities.title, commodities.price, commodities.thumbnail
                     from commodities
                     order by price
                     limit limit_val
                         offset offset_val;
    end if;

end;
$$;

--
SELECT MAX(_id)
FROM commodities;

SELECT nextval('commodities__id_seq1');

SELECT setval('commodities__id_seq1', (SELECT MAX(_id) FROM commodities) + 1);

