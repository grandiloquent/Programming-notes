# ESP8266 & ESP-01 Cheat Sheet

- [File](#file)
- [JSON](#json)
- [String](#string)
- [WiFi](#wifi)
- [WebServer](#webserver)
- [Troubleshooting](#troubleshooting)
	- [ESP-01](#esp-01)


## File

- [void close();](https://github.com/esp8266/Arduino/blob/master/cores/esp8266/FS.h)

### `print`

https://github.com/esp8266/Arduino/blob/master/cores/esp8266/Print.h

```c++
size_t print(const char[]);
```

- [size_t readBytesUntil(char terminator, uint8_t *buffer, size_t length)](https://github.com/esp8266/Arduino/blob/master/cores/esp8266/Stream.h)


## JSON

### ArduinoJson

https://github.com/bblanchon/ArduinoJson

```c++
char json[] = "{\"sensor\":\"gps\",\"time\":1351824120,\"data\":[48.756080,2.302038]}";
	
DynamicJsonDocument doc(1024);
deserializeJson(doc, json);
	
const char* sensor = doc["sensor"];
long time          = doc["time"];
double latitude    = doc["data"][0];
double longitude   = doc["data"][1];
```
	
```c++
DynamicJsonDocument doc(1024);
	
doc["sensor"] = "gps";
doc["time"]   = 1351824120;
	
JsonArray data = doc.createNestedArray("data");
data.add(48.756080);
data.add(2.302038);
	
serializeJson(doc, Serial);
// This prints:
// {"sensor":"gps","time":1351824120,"data":[48.756080,2.302038]}
```	

- [json](https://github.com/esp8266/Arduino/blob/master/tools/sdk/include/json/json.h)

## String

- [`unsigned char startsWith(const String &prefix) const;`](https://github.com/esp8266/Arduino/blob/master/cores/esp8266/WString.h)

## WiFi

- https://docs.espressif.com/projects/esp-idf/en/latest/api-guides/wifi.html

- [`int8_t scanNetworks(bool async = false, bool show_hidden = false, uint8 channel = 0, uint8* ssid = NULL);`](https://github.com/esp8266/Arduino/blob/master/libraries/ESP8266WiFi/src/ESP8266WiFiScan.h)
- [`bool softAPConfig(IPAddress local_ip, IPAddress gateway, IPAddress subnet);`](https://github.com/esp8266/Arduino/blob/master/libraries/ESP8266WiFi/src/ESP8266WiFiAP.h)
- [`bool softAP(const char* ssid, const char* passphrase = NULL, int channel = 1, int ssid_hidden = 0, int max_connection = 4);`](https://github.com/esp8266/Arduino/blob/master/libraries/ESP8266WiFi/src/ESP8266WiFiAP.h)

### `hostname`

https://github.com/esp8266/Arduino/blob/master/libraries/ESP8266WiFi/src/ESP8266WiFiSTA.h

```c++
String hostname();
bool hostname(const String& aHostname) { return hostname(aHostname.c_str()); }
bool hostname(const char* aHostname);
```

### `wifi_set_phy_mode`

- [`bool ESP8266WiFiGenericClass::setPhyMode(WiFiPhyMode_t mode)`](https://github.com/esp8266/Arduino/blob/master/libraries/ESP8266WiFi/src/ESP8266WiFiGeneric.cpp)
- https://github.com/esp8266/Arduino/blob/master/tools/sdk/include/user_interface.h

```c++
typedef enum {
    PHY_MODE_11B    = 1,
    PHY_MODE_11G    = 2,
    PHY_MODE_11N    = 3
} phy_mode_t;

phy_mode_t wifi_get_phy_mode(void);
bool wifi_set_phy_mode(phy_mode_t mode);
```

## WebServer

- [`WiFiServer(const IPAddress& addr, uint16_t port);`](https://github.com/esp8266/Arduino/blob/master/libraries/ESP8266WiFi/src/WiFiServer.h)
- [`WiFiServer(uint16_t port);`](https://github.com/esp8266/Arduino/blob/master/libraries/ESP8266WiFi/src/WiFiServer.h)
- [`void ESP8266WebServerTemplate<ServerType>::handleClient()`](https://github.com/esp8266/Arduino/blob/master/libraries/ESP8266WebServer/src/ESP8266WebServer-impl.h)
- [`void ESP8266WebServerTemplate<ServerType>::sendContent(const String& content)`](https://github.com/esp8266/Arduino/blob/master/libraries/ESP8266WebServer/src/ESP8266WebServer-impl.h)
- [`const String& ESP8266WebServerTemplate<ServerType>::argName(int i) const`](https://github.com/esp8266/Arduino/blob/master/libraries/ESP8266WebServer/src/ESP8266WebServer-impl.h)


## Troubleshooting

### ESP-01

#### espcomm_sync failed

- 未进入下载模式。

	如果使用 ESP LINK 下载固件，额外用一根杜邦线连接 ESP LINK 左端的 GPI0 与 GND 针脚。即第二排第1和第3行的针脚。

	![](/images/esp-link-esp-01.png)

- [I am getting “espcomm_sync failed” error when trying to upload my ESP. How to resolve this issue?](https://arduino-esp8266.readthedocs.io/en/latest/faq/a01-espcomm_sync-failed.html)
